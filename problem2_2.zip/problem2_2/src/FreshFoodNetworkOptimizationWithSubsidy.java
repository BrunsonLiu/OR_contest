import ilog.concert.*;
import ilog.cplex.*;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.nio.charset.StandardCharsets;

public class FreshFoodNetworkOptimizationWithSubsidy {

    // 数据结构
    private static class Warehouse {
        String name;
        String type;
        String location;

        public Warehouse(String name, String type, String location) {
            this.name = name;
            this.type = type;
            this.location = location;
        }
    }

    private static class Customer {
        String name;
        String type;
        String location;

        public Customer(String name, String type, String location) {
            this.name = name;
            this.type = type;
            this.location = location;
        }
    }

    private static class Order {
        String storeName;
        String sku;
        double quantity;

        public Order(String storeName, String sku, double quantity) {
            this.storeName = storeName;
            this.sku = sku;
            this.quantity = quantity;
        }
    }

    private static class MatrixEntry {
        String from;
        String to;
        double distance;
        double duration;

        public MatrixEntry(String from, String to, double distance, double duration) {
            this.from = from;
            this.to = to;
            this.distance = distance;
            this.duration = duration;
        }
    }

    private static class ProcessingInfo {
        double capacity;
        double openingFee;
        double processingFee;

        public ProcessingInfo(double capacity, double openingFee, double processingFee) {
            this.capacity = capacity;
            this.openingFee = openingFee;
            this.processingFee = processingFee;
        }
    }

    // 数据容器
    private List<Warehouse> warehouses = new ArrayList<>();
    private List<Customer> customers = new ArrayList<>();
    private List<Order> orders = new ArrayList<>();
    private List<MatrixEntry> matrixEntries = new ArrayList<>();
    private Map<String, ProcessingInfo> processingInfoMap = new HashMap<>();

    // 预处理后的数据
    private List<String> cdcNames = new ArrayList<>();
    private List<String> rdcNames = new ArrayList<>();
    private String portCDC;
    private String inlandCDC;
    private Map<String, String> storeCityMap = new HashMap<>();
    private Map<Triple<String, String, String>, Double> demand = new HashMap<>();
    private Map<Pair<String, String>, Double> distances = new HashMap<>();
    private Map<Pair<String, String>, Double> travelTimes = new HashMap<>();
    private Map<String, Double> capacities = new HashMap<>();
    private Map<String, Double> openingCosts = new HashMap<>();
    private Map<String, Double> processingCosts = new HashMap<>();

    private IloCplex cplex;

    // 决策变量映射
    private Map<String, IloNumVar> yVars = new HashMap<>();      // 仓库开设
    private Map<String, IloNumVar> zVars = new HashMap<>();      // 智能系统
    private Map<Triple<String, String, String>, IloNumVar> uVars = new HashMap<>(); // 服务关系
    private Map<Pair<String, String>, IloNumVar> vVars = new HashMap<>(); // 时效满足
    private Map<Triple<String, String, String>, IloNumVar> fVars = new HashMap<>(); // 调拨量
    private Map<String, IloNumVar> wVars = new HashMap<>();      // 辅助变量
    private IloNumVar subsidyVar;  // 补贴变量
    private IloNumVar totalOpenWarehousesVar; // 总开仓数量变量

    // 补贴参数
    private static final double SUBSIDY_THRESHOLD = 10.0;  // 补贴门槛：10个仓库
    private static final double SUBSIDY_PER_WAREHOUSE = 7.0; // 每多开一个补贴7万元

    public static void main(String[] args) {
        try {
            FreshFoodNetworkOptimizationWithSubsidy optimizer = new FreshFoodNetworkOptimizationWithSubsidy();
            optimizer.loadData();
            optimizer.buildModel();
            optimizer.solve();
            optimizer.outputResults();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void loadData() throws IOException {
        String inputDir = "C:/Users/86173/Desktop/ORcontest/2025年中国运筹学会运筹竞赛（数据驱动赛道）赛题/赛题3 生鲜商品仓网配送优化/input_data";

        // 读取仓库数据
        readWarehouses(Paths.get(inputDir, "df_wh.csv"));

        // 读取客户数据
        readCustomers(Paths.get(inputDir, "df_customer.csv"));

        // 读取订单数据
        readOrders(Paths.get(inputDir, "df_order.csv"));

        // 读取距离矩阵
        readMatrix(Paths.get(inputDir, "df_matrix.csv"));

        // 读取处理信息
        readProcessingInfo(Paths.get(inputDir, "df_proc.csv"));

        // 预处理数据
        preprocessData();
    }

    // 纯Java CSV解析器
    private List<Map<String, String>> parseCSV(Path filePath) throws IOException {
        List<Map<String, String>> data = new ArrayList<>();
        List<String> headers = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(filePath.toFile()))) {
            String line;
            int lineNum = 0;

            while ((line = br.readLine()) != null) {
                if (lineNum == 0) {
                    // 解析表头
                    headers = parseCSVLine(line);
                } else {
                    // 解析数据行
                    List<String> values = parseCSVLine(line);
                    if (values.size() == headers.size()) {
                        Map<String, String> row = new HashMap<>();
                        for (int i = 0; i < headers.size(); i++) {
                            row.put(headers.get(i), values.get(i));
                        }
                        data.add(row);
                    } else {
                        System.err.println("警告: 第 " + lineNum + " 行列数不匹配: " + values.size() + " != " + headers.size());
                    }
                }
                lineNum++;
            }
        }

        return data;
    }

    // 解析单行CSV，处理引号和逗号
    private List<String> parseCSVLine(String line) {
        List<String> result = new ArrayList<>();
        StringBuilder current = new StringBuilder();
        boolean inQuotes = false;

        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);

            if (c == '"') {
                if (inQuotes && i + 1 < line.length() && line.charAt(i + 1) == '"') {
                    // 转义的双引号
                    current.append('"');
                    i++;
                } else {
                    // 开始或结束引号
                    inQuotes = !inQuotes;
                }
            } else if (c == ',' && !inQuotes) {
                result.add(current.toString().trim());
                current = new StringBuilder();
            } else {
                current.append(c);
            }
        }

        // 添加最后一个字段
        result.add(current.toString().trim());

        // 处理字段中的引号
        for (int i = 0; i < result.size(); i++) {
            String field = result.get(i);
            if (field.startsWith("\"") && field.endsWith("\"") && field.length() > 1) {
                result.set(i, field.substring(1, field.length() - 1));
            }
        }

        return result;
    }

    private void readWarehouses(Path filePath) throws IOException {
        List<Map<String, String>> data = parseCSV(filePath);

        for (Map<String, String> record : data) {
            String name = record.get("Name");
            String type = record.get("Type");
            String location = record.get("Location");
            warehouses.add(new Warehouse(name, type, location));
        }
    }

    private void readCustomers(Path filePath) throws IOException {
        List<Map<String, String>> data = parseCSV(filePath);

        for (Map<String, String> record : data) {
            String name = record.get("Name");
            String type = record.get("Type");
            String location = record.get("Location");
            customers.add(new Customer(name, type, location));
            storeCityMap.put(name, location);
        }
    }

    private void readOrders(Path filePath) throws IOException {
        List<Map<String, String>> data = parseCSV(filePath);

        for (Map<String, String> record : data) {
            String name = record.get("Name");
            String sku = record.get("SKU");
            String qtyStr = record.get("qty");

            try {
                double qty = Double.parseDouble(qtyStr);
                orders.add(new Order(name, sku, qty));
                demand.put(new Triple<>(name, sku, ""), qty);
            } catch (NumberFormatException e) {
                System.err.println("无法解析订单数量: " + qtyStr + " for " + name + " SKU: " + sku);
            }
        }
    }

    private void readMatrix(Path filePath) throws IOException {
        List<Map<String, String>> data = parseCSV(filePath);

        for (Map<String, String> record : data) {
            String from = record.get("From");
            String to = record.get("To");
            String distanceStr = record.get("Distance");
            String durationStr = record.get("Duration");

            try {
                double distance = Double.parseDouble(distanceStr);
                double duration = Double.parseDouble(durationStr);
                matrixEntries.add(new MatrixEntry(from, to, distance, duration));

                distances.put(new Pair<>(from, to), distance);
                travelTimes.put(new Pair<>(from, to), duration);
            } catch (NumberFormatException e) {
                System.err.println("无法解析距离或时间: " + distanceStr + " / " + durationStr);
            }
        }
    }

    private void readProcessingInfo(Path filePath) throws IOException {
        List<Map<String, String>> data = parseCSV(filePath);

        for (Map<String, String> record : data) {
            String name = record.get("Name");
            String capacityStr = record.get("Capacity");
            String processingFeeStr = record.get("Processing_fee");
            String openingFeeStr = record.get("Opening_fee");

            try {
                double capacity = Double.parseDouble(capacityStr);
                double processingFee = Double.parseDouble(processingFeeStr);
                double openingFee = Double.parseDouble(openingFeeStr);
                processingInfoMap.put(name, new ProcessingInfo(capacity, openingFee, processingFee));
            } catch (NumberFormatException e) {
                System.err.println("无法解析仓储数据: " + name + " " + capacityStr + " " + processingFeeStr + " " + openingFeeStr);
            }
        }
    }

    private void preprocessData() {
        // 识别CDC和RDC
        for (Warehouse wh : warehouses) {
            if ("CDC".equals(wh.type)) {
                cdcNames.add(wh.name);
            } else if ("RDC".equals(wh.type)) {
                rdcNames.add(wh.name);
            }
        }

        // 识别港口CDC和内陆CDC
        for (String cdc : cdcNames) {
            if (cdc.contains("gang-kou")) {
                portCDC = cdc;
            } else if (cdc.contains("nei-lu")) {
                inlandCDC = cdc;
            }
        }

        System.out.println("港口CDC: " + portCDC);
        System.out.println("内陆CDC: " + inlandCDC);
        System.out.println("CDC数量: " + cdcNames.size());
        System.out.println("RDC数量: " + rdcNames.size());
        System.out.println("订单数量: " + orders.size());

        // 仓库参数
        for (Warehouse wh : warehouses) {
            if (("CDC".equals(wh.type) || "RDC".equals(wh.type))
                    && processingInfoMap.containsKey(wh.name)) {
                ProcessingInfo info = processingInfoMap.get(wh.name);
                capacities.put(wh.name, info.capacity);
                openingCosts.put(wh.name, info.openingFee);
                processingCosts.put(wh.name, info.processingFee);
            }
        }
    }

    private void buildModel() throws IloException {
        cplex = new IloCplex();
        cplex.setOut(null); // 减少输出

        // 最小化目标
        cplex.setParam(IloCplex.Param.RootAlgorithm, IloCplex.Algorithm.Auto);
        cplex.setParam(IloCplex.Param.Threads, 8);

        // 创建决策变量
        createVariables();

        // 添加约束
        addConstraints();

        // 添加目标函数（企业成本最小化）
        addObjectiveFunction();
    }

    private void createVariables() throws IloException {
        // 1. 仓库开设变量 y
        for (Warehouse wh : warehouses) {
            if ("RDC".equals(wh.type) || "CDC".equals(wh.type)) {
                String varName = "y_" + wh.name;
                IloNumVar var;

                if (cdcNames.contains(wh.name)) {
                    // CDC必开
                    var = cplex.numVar(1.0, 1.0, IloNumVarType.Bool, varName);
                } else {
                    var = cplex.numVar(0.0, 1.0, IloNumVarType.Bool, varName);
                }

                yVars.put(wh.name, var);
            }
        }

        System.out.println("已创建仓库开设变量: " + yVars.size());

        // 2. 智能系统变量 z
        for (Warehouse wh : warehouses) {
            if ("RDC".equals(wh.type) || "CDC".equals(wh.type)) {
                String varName = "z_" + wh.name;
                IloNumVar var = cplex.numVar(0.0, 1.0, IloNumVarType.Bool, varName);
                zVars.put(wh.name, var);
            }
        }

        System.out.println("已创建智能系统变量: " + zVars.size());

        // 3. 服务关系变量 u
        for (Order order : orders) {
            String store = order.storeName;
            String sku = order.sku;

            List<String> eligibleWarehouses = new ArrayList<>();
            if ("im".equals(sku)) {
                eligibleWarehouses.add(portCDC);
                eligibleWarehouses.addAll(rdcNames);
            } else {
                eligibleWarehouses.add(inlandCDC);
                eligibleWarehouses.addAll(rdcNames);
            }

            for (String wh : eligibleWarehouses) {
                String varName = String.format("u_%s_%s_%s", wh, store, sku);
                IloNumVar var = cplex.numVar(0.0, 1.0, IloNumVarType.Bool, varName);
                uVars.put(new Triple<>(wh, store, sku), var);
            }
        }

        System.out.println("已创建服务关系变量: " + uVars.size());

        // 4. 时效满足变量 v
        for (Order order : orders) {
            String store = order.storeName;
            String sku = order.sku;
            String varName = String.format("v_%s_%s", store, sku);
            IloNumVar var = cplex.numVar(0.0, 1.0, IloNumVarType.Bool, varName);
            vVars.put(new Pair<>(store, sku), var);
        }

        System.out.println("已创建时效满足变量: " + vVars.size());

        // 5. 调拨量变量 f
        for (String cdc : cdcNames) {
            for (String rdc : rdcNames) {
                for (String sku : Arrays.asList("im", "dm")) {
                    // 检查调拨是否允许
                    if (("im".equals(sku) && cdc.equals(portCDC))
                            || ("dm".equals(sku) && cdc.equals(inlandCDC))) {
                        String varName = String.format("f_%s_%s_%s", cdc, rdc, sku);
                        IloNumVar var = cplex.numVar(0.0, Double.MAX_VALUE, IloNumVarType.Float, varName);
                        fVars.put(new Triple<>(cdc, rdc, sku), var);
                    }
                }
            }
        }

        System.out.println("已创建调拨量变量: " + fVars.size());

        // 6. 线性化辅助变量 w
        for (Warehouse wh : warehouses) {
            if ("RDC".equals(wh.type) || "CDC".equals(wh.type)) {
                String varName = "w_" + wh.name;
                IloNumVar var = cplex.numVar(0.0, Double.MAX_VALUE, IloNumVarType.Float, varName);
                wVars.put(wh.name, var);
            }
        }

        // 7. 补贴变量（连续变量）
        subsidyVar = cplex.numVar(0.0, Double.MAX_VALUE, IloNumVarType.Float, "subsidy");

        // 8. 总开仓数量变量（连续变量）
        totalOpenWarehousesVar = cplex.numVar(0.0, yVars.size(), IloNumVarType.Float, "total_open");

        System.out.println("总变量数: " + (yVars.size() + zVars.size() + uVars.size() + vVars.size() + fVars.size() + wVars.size() + 2));
    }

    private void addConstraints() throws IloException {
        int constraintCount = 0;

        // 1. 单源服务约束
        for (Order order : orders) {
            String store = order.storeName;
            String sku = order.sku;

            List<String> eligibleWarehouses = new ArrayList<>();
            if ("im".equals(sku)) {
                eligibleWarehouses.add(portCDC);
                eligibleWarehouses.addAll(rdcNames);
            } else {
                eligibleWarehouses.add(inlandCDC);
                eligibleWarehouses.addAll(rdcNames);
            }

            IloLinearNumExpr expr = cplex.linearNumExpr();
            for (String wh : eligibleWarehouses) {
                Triple<String, String, String> key = new Triple<>(wh, store, sku);
                if (uVars.containsKey(key)) {
                    expr.addTerm(1.0, uVars.get(key));
                }
            }

            cplex.addEq(expr, 1.0, "single_source_" + constraintCount++);
        }

        System.out.println("已添加单源服务约束: " + constraintCount);

        // 2. 仓库开设与服务关系约束
        for (Map.Entry<Triple<String, String, String>, IloNumVar> entry : uVars.entrySet()) {
            Triple<String, String, String> key = entry.getKey();
            String wh = key.first;

            IloLinearNumExpr expr = cplex.linearNumExpr();
            expr.addTerm(1.0, entry.getValue());
            expr.addTerm(-1.0, yVars.get(wh));

            cplex.addLe(expr, 0.0, "service_open_" + constraintCount++);
        }

        // 3. RDC流量平衡约束
        double M = orders.stream().mapToDouble(o -> o.quantity).sum();

        for (String rdc : rdcNames) {
            for (String sku : Arrays.asList("im", "dm")) {
                IloLinearNumExpr expr = cplex.linearNumExpr();

                // RDC出发的配送
                for (Order order : orders) {
                    if (order.sku.equals(sku)) {
                        Triple<String, String, String> key = new Triple<>(rdc, order.storeName, sku);
                        if (uVars.containsKey(key)) {
                            expr.addTerm(order.quantity, uVars.get(key));
                        }
                    }
                }

                // CDC到RDC的调拨
                String cdc = "im".equals(sku) ? portCDC : inlandCDC;
                Triple<String, String, String> fKey = new Triple<>(cdc, rdc, sku);
                if (fVars.containsKey(fKey)) {
                    expr.addTerm(-1.0, fVars.get(fKey));
                }

                cplex.addEq(expr, 0.0, "balance_" + constraintCount++);
            }
        }

        // 4. 容量约束
        for (String wh : capacities.keySet()) {
            IloLinearNumExpr expr = cplex.linearNumExpr();

            if (cdcNames.contains(wh)) {
                // CDC的出库包括调拨和直接配送
                for (String rdc : rdcNames) {
                    for (String sku : Arrays.asList("im", "dm")) {
                        Triple<String, String, String> key = new Triple<>(wh, rdc, sku);
                        if (fVars.containsKey(key)) {
                            expr.addTerm(1.0, fVars.get(key));
                        }
                    }
                }

                for (Order order : orders) {
                    Triple<String, String, String> key = new Triple<>(wh, order.storeName, order.sku);
                    if (uVars.containsKey(key)) {
                        expr.addTerm(order.quantity, uVars.get(key));
                    }
                }
            } else {
                // RDC只有直接配送
                for (Order order : orders) {
                    Triple<String, String, String> key = new Triple<>(wh, order.storeName, order.sku);
                    if (uVars.containsKey(key)) {
                        expr.addTerm(order.quantity, uVars.get(key));
                    }
                }
            }

            // 减去容量*y
            if (yVars.containsKey(wh)) {
                expr.addTerm(-capacities.get(wh), yVars.get(wh));
                cplex.addLe(expr, 0.0, "capacity_" + constraintCount++);
            }
        }

        // 5. 线性化约束：w_j = z_j * 总流量
        double bigM = 1000000.0;

        for (String wh : wVars.keySet()) {
            if (!processingCosts.containsKey(wh)) continue;

            // 计算总流量
            IloLinearNumExpr totalFlowExpr = cplex.linearNumExpr();

            if (cdcNames.contains(wh)) {
                // CDC的总流量（出库量）
                for (String rdc : rdcNames) {
                    for (String sku : Arrays.asList("im", "dm")) {
                        Triple<String, String, String> key = new Triple<>(wh, rdc, sku);
                        if (fVars.containsKey(key)) {
                            totalFlowExpr.addTerm(1.0, fVars.get(key));
                        }
                    }
                }

                for (Order order : orders) {
                    Triple<String, String, String> key = new Triple<>(wh, order.storeName, order.sku);
                    if (uVars.containsKey(key)) {
                        totalFlowExpr.addTerm(order.quantity, uVars.get(key));
                    }
                }
            } else {
                // RDC的总流量（流入量）
                for (String sku : Arrays.asList("im", "dm")) {
                    String cdc = "im".equals(sku) ? portCDC : inlandCDC;
                    Triple<String, String, String> key = new Triple<>(cdc, wh, sku);
                    if (fVars.containsKey(key)) {
                        totalFlowExpr.addTerm(1.0, fVars.get(key));
                    }
                }

                for (Order order : orders) {
                    Triple<String, String, String> key = new Triple<>(wh, order.storeName, order.sku);
                    if (uVars.containsKey(key)) {
                        totalFlowExpr.addTerm(order.quantity, uVars.get(key));
                    }
                }
            }

            // 线性化约束
            IloLinearNumExpr expr1 = cplex.linearNumExpr();
            expr1.addTerm(1.0, wVars.get(wh));
            expr1.addTerm(-bigM, zVars.get(wh));
            cplex.addLe(expr1, 0.0, "linear1_" + constraintCount++);

            IloLinearNumExpr expr2 = cplex.linearNumExpr();
            expr2.addTerm(1.0, wVars.get(wh));
            cplex.addLe(expr2, totalFlowExpr, "linear2_" + constraintCount++);

            IloLinearNumExpr expr3 = cplex.linearNumExpr();
            expr3.addTerm(1.0, wVars.get(wh));
            expr3.addTerm(bigM, zVars.get(wh));
            cplex.addGe(expr3, totalFlowExpr, "linear3_" + constraintCount++);
        }

        // 6. 时效约束
        double totalDemand = orders.stream().mapToDouble(o -> o.quantity).sum();

        for (Map.Entry<Pair<String, String>, IloNumVar> entry : vVars.entrySet()) {
            Pair<String, String> key = entry.getKey();
            String store = key.first;
            String sku = key.second;

            List<String> eligibleWarehouses = new ArrayList<>();
            if ("im".equals(sku)) {
                eligibleWarehouses.add(portCDC);
                eligibleWarehouses.addAll(rdcNames);
            } else {
                eligibleWarehouses.add(inlandCDC);
                eligibleWarehouses.addAll(rdcNames);
            }

            for (String wh : eligibleWarehouses) {
                Triple<String, String, String> uKey = new Triple<>(wh, store, sku);
                if (uVars.containsKey(uKey)) {
                    double travelTime = travelTimes.getOrDefault(new Pair<>(wh, store), Double.MAX_VALUE);

                    if (travelTime <= 600) {
                        IloLinearNumExpr expr = cplex.linearNumExpr();
                        expr.addTerm(-1.0, entry.getValue());
                        expr.addTerm(1.0, uVars.get(uKey));
                        cplex.addLe(expr, 0.0, "time1_" + constraintCount++);
                    } else {
                        IloLinearNumExpr expr = cplex.linearNumExpr();
                        expr.addTerm(1.0, entry.getValue());
                        expr.addTerm(1.0, uVars.get(uKey));
                        cplex.addLe(expr, 1.0, "time2_" + constraintCount++);
                    }
                }
            }
        }

        // 整体时效约束
        IloLinearNumExpr expr = cplex.linearNumExpr();
        for (Map.Entry<Pair<String, String>, IloNumVar> entry : vVars.entrySet()) {
            Pair<String, String> key = entry.getKey();
            double demandQty = demand.getOrDefault(new Triple<>(key.first, key.second, ""), 0.0);
            expr.addTerm(demandQty, entry.getValue());
        }
        cplex.addGe(expr, 0.95 * totalDemand, "overall_time_window_" + constraintCount++);

        // 7. 智能系统采购约束
        for (String wh : zVars.keySet()) {
            if (yVars.containsKey(wh)) {
                IloLinearNumExpr expr2 = cplex.linearNumExpr();
                expr2.addTerm(1.0, zVars.get(wh));
                expr2.addTerm(-1.0, yVars.get(wh));
                cplex.addLe(expr2, 0.0, "system_" + constraintCount++);
            }
        }

        // 8. 总开仓数量约束
        IloLinearNumExpr totalOpenExpr = cplex.linearNumExpr();
        for (IloNumVar yVar : yVars.values()) {
            totalOpenExpr.addTerm(1.0, yVar);
        }
        cplex.addEq(totalOpenWarehousesVar, totalOpenExpr, "total_open_constraint_" + constraintCount++);

        // 9. 补贴约束（分段线性函数）
        // 当总开仓数量 >= 10时，补贴 = 7 * (总开仓数量 - 10)
        // 当总开仓数量 < 10时，补贴 = 0
        // 使用大M法线性化

        // 引入二进制变量指示是否超过10个仓库
        IloNumVar overThreshold = cplex.numVar(0.0, 1.0, IloNumVarType.Bool, "over_threshold");

        // 约束1: 总开仓数量 - 10 <= bigM * overThreshold
        IloLinearNumExpr expr3 = cplex.linearNumExpr();
        expr3.addTerm(1.0, totalOpenWarehousesVar);
        expr3.addTerm(-bigM, overThreshold);
        cplex.addLe(expr3, SUBSIDY_THRESHOLD, "subsidy1_" + constraintCount++);

        // 约束2: 总开仓数量 - 10 >= -bigM * (1 - overThreshold)
        IloLinearNumExpr expr4 = cplex.linearNumExpr();
        expr4.addTerm(1.0, totalOpenWarehousesVar);
        expr4.addTerm(bigM, overThreshold);
        cplex.addGe(expr4, SUBSIDY_THRESHOLD - bigM, "subsidy2_" + constraintCount++);

        // 约束3: 补贴 <= bigM * overThreshold
        IloLinearNumExpr expr5 = cplex.linearNumExpr();
        expr5.addTerm(1.0, subsidyVar);
        expr5.addTerm(-bigM, overThreshold);
        cplex.addLe(expr5, 0.0, "subsidy3_" + constraintCount++);

        // 约束4: 补贴 <= SUBSIDY_PER_WAREHOUSE * (总开仓数量 - 10) + bigM * (1 - overThreshold)
        IloLinearNumExpr expr6 = cplex.linearNumExpr();
        expr6.addTerm(1.0, subsidyVar);
        expr6.addTerm(-SUBSIDY_PER_WAREHOUSE, totalOpenWarehousesVar);
        expr6.addTerm(bigM, overThreshold);
        cplex.addLe(expr6, -SUBSIDY_PER_WAREHOUSE * SUBSIDY_THRESHOLD + bigM, "subsidy4_" + constraintCount++);

        // 约束5: 补贴 >= SUBSIDY_PER_WAREHOUSE * (总开仓数量 - 10) - bigM * (1 - overThreshold)
        IloLinearNumExpr expr7 = cplex.linearNumExpr();
        expr7.addTerm(1.0, subsidyVar);
        expr7.addTerm(-SUBSIDY_PER_WAREHOUSE, totalOpenWarehousesVar);
        expr7.addTerm(-bigM, overThreshold);
        cplex.addGe(expr7, -SUBSIDY_PER_WAREHOUSE * SUBSIDY_THRESHOLD - bigM, "subsidy5_" + constraintCount++);

        // 约束6: 当overThreshold=0时，补贴=0
        IloLinearNumExpr expr8 = cplex.linearNumExpr();
        expr8.addTerm(1.0, subsidyVar);
        expr8.addTerm(bigM, overThreshold);
        cplex.addGe(expr8, 0.0, "subsidy6_" + constraintCount++);

        System.out.println("总约束数: " + constraintCount);
    }

    private void addObjectiveFunction() throws IloException {
        IloLinearNumExpr objective = cplex.linearNumExpr();

        // 1. 开仓成本
        for (Map.Entry<String, IloNumVar> entry : yVars.entrySet()) {
            String wh = entry.getKey();
            double cost = openingCosts.getOrDefault(wh, 0.0);
            objective.addTerm(cost, entry.getValue());
        }

        // 2. 智能系统成本
        for (Map.Entry<String, IloNumVar> entry : zVars.entrySet()) {
            objective.addTerm(1.5, entry.getValue());
        }

        // 3. 运输成本 - 仓库到门店
        for (Map.Entry<Triple<String, String, String>, IloNumVar> entry : uVars.entrySet()) {
            Triple<String, String, String> key = entry.getKey();
            String wh = key.first;
            String store = key.second;
            String sku = key.third;

            double distance = distances.getOrDefault(new Pair<>(wh, store), 0.0);
            double demandQty = demand.getOrDefault(new Triple<>(store, sku, ""), 0.0);
            double cost = 1.45 / 10000.0 * distance * demandQty;

            objective.addTerm(cost, entry.getValue());
        }

        // 4. 运输成本 - CDC到RDC
        for (Map.Entry<Triple<String, String, String>, IloNumVar> entry : fVars.entrySet()) {
            Triple<String, String, String> key = entry.getKey();
            String cdc = key.first;
            String rdc = key.second;

            double distance = distances.getOrDefault(new Pair<>(cdc, rdc), 0.0);
            double cost = 0.9 / 10000.0 * distance;

            objective.addTerm(cost, entry.getValue());
        }

        // 5. 处理成本
        for (String wh : processingCosts.keySet()) {
            double procCost = processingCosts.get(wh);

            if (cdcNames.contains(wh)) {
                for (String rdc : rdcNames) {
                    for (String sku : Arrays.asList("im", "dm")) {
                        Triple<String, String, String> key = new Triple<>(wh, rdc, sku);
                        if (fVars.containsKey(key)) {
                            objective.addTerm(2.0 * procCost, fVars.get(key));
                        }
                    }
                }

                for (Order order : orders) {
                    Triple<String, String, String> key = new Triple<>(wh, order.storeName, order.sku);
                    if (uVars.containsKey(key)) {
                        objective.addTerm(2.0 * procCost * order.quantity, uVars.get(key));
                    }
                }
            } else {
                for (String sku : Arrays.asList("im", "dm")) {
                    String cdc = "im".equals(sku) ? portCDC : inlandCDC;
                    Triple<String, String, String> key = new Triple<>(cdc, wh, sku);
                    if (fVars.containsKey(key)) {
                        objective.addTerm(procCost, fVars.get(key));
                    }
                }

                for (Order order : orders) {
                    Triple<String, String, String> key = new Triple<>(wh, order.storeName, order.sku);
                    if (uVars.containsKey(key)) {
                        objective.addTerm(procCost * order.quantity, uVars.get(key));
                    }
                }
            }

            if (wVars.containsKey(wh)) {
                if (cdcNames.contains(wh)) {
                    objective.addTerm(-0.8 * procCost, wVars.get(wh));
                } else {
                    objective.addTerm(-0.4 * procCost, wVars.get(wh));
                }
            }
        }

        // 6. 减去补贴（企业成本最小化）
        objective.addTerm(-1.0, subsidyVar);

        cplex.addMinimize(objective);
        System.out.println("目标函数构建完成（企业成本最小化）");
    }

    private void solve() throws IloException {
        System.out.println("求解模型...");

        if (cplex.solve()) {
            System.out.println("求解状态: " + cplex.getStatus());
            System.out.printf("最优企业成本: %.2f 万元%n", cplex.getObjValue());

            double totalOpen = cplex.getValue(totalOpenWarehousesVar);
            double subsidy = cplex.getValue(subsidyVar);
            double socialCost = cplex.getObjValue() + subsidy; // 社会总成本 = 企业成本 + 补贴

            System.out.printf("开仓数量: %.0f%n", totalOpen);
            System.out.printf("补贴金额: %.2f 万元%n", subsidy);
            System.out.printf("社会总成本: %.2f 万元%n", socialCost);

            // 输出智能系统采购情况
            int systemCount = 0;
            for (Map.Entry<String, IloNumVar> entry : zVars.entrySet()) {
                double zValue = cplex.getValue(entry.getValue());
                if (zValue > 0.5) {
                    systemCount++;
                }
            }
            System.out.printf("共采购了 %d 个智能系统%n", systemCount);
        } else {
            System.out.println("求解失败，状态: " + cplex.getStatus());
        }
    }

    private void outputResults() throws IloException, IOException {
        if (!cplex.getStatus().equals(IloCplex.Status.Optimal)) {
            System.out.println("未找到最优解，无法输出结果");
            return;
        }

        String outputDir = "./2025年中国运筹学会运筹竞赛（数据驱动赛道）赛题/赛题3 生鲜商品仓网配送优化/output_result";
        Files.createDirectories(Paths.get(outputDir));

        // 输出三个结果文件，与第一个问题保持一致
        outputBusinessPerformance(outputDir);
        outputWarehouseProcessing(outputDir);
        outputSupplyRelationships(outputDir);

        System.out.println("问题二第二小问求解完成！");
    }

    private void outputBusinessPerformance(String outputDir) throws IloException, IOException {
        // 计算各指标
        int openWarehouseCount = 0;
        for (String wh : yVars.keySet()) {
            if (cplex.getValue(yVars.get(wh)) > 0.5) {
                openWarehouseCount++;
            }
        }

        // 计算满意需求
        double satisfiedDemand = 0.0;
        double totalDemand = orders.stream().mapToDouble(o -> o.quantity).sum();

        for (Map.Entry<Pair<String, String>, IloNumVar> entry : vVars.entrySet()) {
            Pair<String, String> key = entry.getKey();
            double demandQty = demand.getOrDefault(new Triple<>(key.first, key.second, ""), 0.0);
            satisfiedDemand += demandQty * cplex.getValue(entry.getValue());
        }

        double satisfactionRate = satisfiedDemand / totalDemand;

        // 计算运输成本
        double transportWh = 0.0; // 仓库间运输成本
        for (Map.Entry<Triple<String, String, String>, IloNumVar> entry : fVars.entrySet()) {
            Triple<String, String, String> key = entry.getKey();
            String from = key.first;
            String to = key.second;
            double distance = distances.getOrDefault(new Pair<>(from, to), 0.0);
            double flow = cplex.getValue(entry.getValue());
            transportWh += 0.9 / 10000.0 * distance * flow;
        }

        double transportCust = 0.0; // 仓库到门店运输成本
        for (Map.Entry<Triple<String, String, String>, IloNumVar> entry : uVars.entrySet()) {
            Triple<String, String, String> key = entry.getKey();
            String wh = key.first;
            String store = key.second;
            String sku = key.third;
            double distance = distances.getOrDefault(new Pair<>(wh, store), 0.0);
            double demandQty = demand.getOrDefault(new Triple<>(store, sku, ""), 0.0);
            double uValue = cplex.getValue(entry.getValue());
            transportCust += 1.45 / 10000.0 * distance * demandQty * uValue;
        }

        // 开仓成本
        double openingCost = 0.0;
        for (Map.Entry<String, IloNumVar> entry : yVars.entrySet()) {
            String wh = entry.getKey();
            double yValue = cplex.getValue(entry.getValue());
            openingCost += openingCosts.getOrDefault(wh, 0.0) * yValue;
        }

        // 智能系统成本
        double systemCost = 0.0;
        for (Map.Entry<String, IloNumVar> entry : zVars.entrySet()) {
            double zValue = cplex.getValue(entry.getValue());
            systemCost += 1.5 * zValue;
        }

        // 处理成本 - 应用智能系统折扣
        double processingCost = 0.0;
        for (String wh : processingCosts.keySet()) {
            if (cplex.getValue(yVars.get(wh)) > 0.5) { // 只计算已开仓库
                double procCost = processingCosts.get(wh);
                double totalQty = 0.0;

                if (cdcNames.contains(wh)) {
                    // CDC处理量计算
                    for (String rdc : rdcNames) {
                        for (String sku : Arrays.asList("im", "dm")) {
                            Triple<String, String, String> key = new Triple<>(wh, rdc, sku);
                            if (fVars.containsKey(key)) {
                                totalQty += 2.0 * cplex.getValue(fVars.get(key));
                            }
                        }
                    }

                    for (Order order : orders) {
                        Triple<String, String, String> key = new Triple<>(wh, order.storeName, order.sku);
                        if (uVars.containsKey(key)) {
                            totalQty += 2.0 * order.quantity * cplex.getValue(uVars.get(key));
                        }
                    }
                } else {
                    // RDC处理量计算
                    for (String sku : Arrays.asList("im", "dm")) {
                        String cdc = "im".equals(sku) ? portCDC : inlandCDC;
                        Triple<String, String, String> key = new Triple<>(cdc, wh, sku);
                        if (fVars.containsKey(key)) {
                            totalQty += cplex.getValue(fVars.get(key));
                        }
                    }

                    for (Order order : orders) {
                        Triple<String, String, String> key = new Triple<>(wh, order.storeName, order.sku);
                        if (uVars.containsKey(key)) {
                            totalQty += order.quantity * cplex.getValue(uVars.get(key));
                        }
                    }
                }

                // 应用智能系统折扣
                double discountFactor = 1.0;
                if (zVars.containsKey(wh) && cplex.getValue(zVars.get(wh)) > 0.5) {
                    discountFactor = 0.6;
                }

                processingCost += procCost * totalQty * discountFactor;
            }
        }

        // 计算补贴
        double subsidy = cplex.getValue(subsidyVar);

        // 企业成本（目标函数值）
        double enterpriseCost = cplex.getObjValue();

        // 社会总成本 = 企业成本 + 补贴
        double socialCost = enterpriseCost + subsidy;

        // 总物流成本 = 仓库间运输成本 + 仓库到门店运输成本
        double totalTransportCost = transportWh + transportCust;

        // 总成本 = 开仓成本 + 处理成本 + 智能系统成本 + 总物流成本 - 补贴
        double totalCostWithoutSubsidy = openingCost + processingCost + systemCost + totalTransportCost;

        // 验证成本一致性
        System.out.printf("成本验证: 开仓成本=%.2f, 处理成本=%.2f, 智能系统=%.2f, 运输成本=%.2f, 总成本(不含补贴)=%.2f, 企业成本=%.2f, 补贴=%.2f, 社会总成本=%.2f%n",
                openingCost, processingCost, systemCost, totalTransportCost,
                totalCostWithoutSubsidy, enterpriseCost, subsidy, socialCost);

        // 创建输出数据 - 按照第一个问题的格式，增加社会总成本
        List<String> headers = Arrays.asList(
                "开仓数量", "时效满足率", "总物流成本",
                "仓库之间的运输总成本", "仓库到门店的运输总成本",
                "开仓总成本", "出入仓处置总成本",
                "智能调度系统采购总成本",
                "补贴金额", "企业成本", "社会总成本"
        );

        Path outputPath = Paths.get(outputDir, "仓网业务表现文件_cplex_subsidy.csv");
        try (Writer writer = Files.newBufferedWriter(outputPath, StandardCharsets.UTF_8)) {
            // 写入表头
            writer.write(String.join(",", headers));
            writer.write("\n");

            // 写入数据
            List<String> values = Arrays.asList(
                    String.valueOf(openWarehouseCount),
                    String.format("%.4f", satisfactionRate),
                    String.format("%.2f", totalTransportCost),
                    String.format("%.2f", transportWh),
                    String.format("%.2f", transportCust),
                    String.format("%.2f", openingCost),
                    String.format("%.2f", processingCost),
                    String.format("%.2f", systemCost),
                    String.format("%.2f", subsidy),
                    String.format("%.2f", enterpriseCost),
                    String.format("%.2f", socialCost)
            );
            writer.write(String.join(",", values));
        }

        System.out.println("仓网业务表现文件_cplex_subsidy.csv已保存");
        System.out.printf("开仓数量: %d, 时效满足率: %.4f, 社会总成本: %.2f万元, 企业成本: %.2f万元, 补贴: %.2f万元%n",
                openWarehouseCount, satisfactionRate, socialCost, enterpriseCost, subsidy);
    }

    private void outputWarehouseProcessing(String outputDir) throws IloException, IOException {
        List<String[]> data = new ArrayList<>();
        data.add(new String[]{"Name", "SKU", "Qty（单位：吨）"});

        // 统计每个仓库每种SKU的处理量
        for (String wh : yVars.keySet()) {
            if (cplex.getValue(yVars.get(wh)) > 0.5) {
                // 统计进口海鲜
                double imQty = 0.0;
                double dmQty = 0.0;

                if (cdcNames.contains(wh)) {
                    // CDC的处理量是出库量的2倍
                    // 进口海鲜
                    for (String rdc : rdcNames) {
                        Triple<String, String, String> key = new Triple<>(wh, rdc, "im");
                        if (fVars.containsKey(key)) {
                            imQty += 2.0 * cplex.getValue(fVars.get(key));
                        }
                    }

                    // 国产海鲜
                    for (String rdc : rdcNames) {
                        Triple<String, String, String> key = new Triple<>(wh, rdc, "dm");
                        if (fVars.containsKey(key)) {
                            dmQty += 2.0 * cplex.getValue(fVars.get(key));
                        }
                    }

                    // 直接配送
                    for (Order order : orders) {
                        Triple<String, String, String> key = new Triple<>(wh, order.storeName, order.sku);
                        if (uVars.containsKey(key)) {
                            double uValue = cplex.getValue(uVars.get(key));
                            if ("im".equals(order.sku)) {
                                imQty += order.quantity * uValue;
                            } else {
                                dmQty += order.quantity * uValue;
                            }
                        }
                    }
                } else {
                    // RDC的处理量是调拨入量+直配量
                    // 进口海鲜调拨
                    if (portCDC != null) {
                        Triple<String, String, String> key = new Triple<>(portCDC, wh, "im");
                        if (fVars.containsKey(key)) {
                            imQty += cplex.getValue(fVars.get(key));
                        }
                    }

                    // 国产海鲜调拨
                    if (inlandCDC != null) {
                        Triple<String, String, String> key = new Triple<>(inlandCDC, wh, "dm");
                        if (fVars.containsKey(key)) {
                            dmQty += cplex.getValue(fVars.get(key));
                        }
                    }

                    // 直接配送
                    for (Order order : orders) {
                        Triple<String, String, String> key = new Triple<>(wh, order.storeName, order.sku);
                        if (uVars.containsKey(key)) {
                            double uValue = cplex.getValue(uVars.get(key));
                            if ("im".equals(order.sku)) {
                                imQty += order.quantity * uValue;
                            } else {
                                dmQty += order.quantity * uValue;
                            }
                        }
                    }
                }

                // 只输出有处理量的行
                if (imQty > 0.01) {
                    data.add(new String[]{wh, "im", String.format("%.2f", imQty)});
                }
                if (dmQty > 0.01) {
                    data.add(new String[]{wh, "dm", String.format("%.2f", dmQty)});
                }
            }
        }

        Path outputPath = Paths.get(outputDir, "仓库处置订单量文件_cplex_subsidy.csv");
        try (Writer writer = Files.newBufferedWriter(outputPath, StandardCharsets.UTF_8)) {
            for (String[] row : data) {
                writer.write(String.join(",", row));
                writer.write("\n");
            }
        }

        System.out.println("仓库处置订单量文件_cplex_subsidy.csv已保存");
    }

    private void outputSupplyRelationships(String outputDir) throws IloException, IOException {
        List<String[]> data = new ArrayList<>();
        data.add(new String[]{"Name", "Customer", "SKU", "Qty（单位：吨）"});

        // CDC到RDC的调拨
        for (Map.Entry<Triple<String, String, String>, IloNumVar> entry : fVars.entrySet()) {
            Triple<String, String, String> key = entry.getKey();
            String from = key.first;
            String to = key.second;
            String sku = key.third;

            double qty = cplex.getValue(entry.getValue());
            if (qty > 0.01) {
                data.add(new String[]{from, to, sku, String.format("%.2f", qty)});
            }
        }

        // 仓库到门店的配送
        for (Map.Entry<Triple<String, String, String>, IloNumVar> entry : uVars.entrySet()) {
            Triple<String, String, String> key = entry.getKey();
            String wh = key.first;
            String store = key.second;
            String sku = key.third;

            double uValue = cplex.getValue(entry.getValue());
            if (uValue > 0.5) {
                double demandQty = demand.getOrDefault(new Triple<>(store, sku, ""), 0.0);
                String city = storeCityMap.getOrDefault(store, store);
                data.add(new String[]{wh, city, sku, String.format("%.2f", demandQty)});
            }
        }

        Path outputPath = Paths.get(outputDir, "仓网供应关系文件_cplex_subsidy.csv");
        try (Writer writer = Files.newBufferedWriter(outputPath, StandardCharsets.UTF_8)) {
            for (String[] row : data) {
                writer.write(String.join(",", row));
                writer.write("\n");
            }
        }

        System.out.println("仓网供应关系文件_cplex_subsidy.csv已保存");
    }

    private void outputSubsidyAnalysis(String outputDir) throws IloException, IOException {
        // 计算企业成本、社会总成本等
        double enterpriseCost = cplex.getObjValue(); // 企业成本（目标函数值）
        double subsidy = cplex.getValue(subsidyVar);
        double socialCost = enterpriseCost + subsidy; // 社会总成本

        // 计算开仓数量
        int openWarehouseCount = 0;
        for (String wh : yVars.keySet()) {
            if (cplex.getValue(yVars.get(wh)) > 0.5) {
                openWarehouseCount++;
            }
        }

        // 计算满意需求
        double satisfiedDemand = 0.0;
        double totalDemand = orders.stream().mapToDouble(o -> o.quantity).sum();

        for (Map.Entry<Pair<String, String>, IloNumVar> entry : vVars.entrySet()) {
            Pair<String, String> key = entry.getKey();
            double demandQty = demand.getOrDefault(new Triple<>(key.first, key.second, ""), 0.0);
            satisfiedDemand += demandQty * cplex.getValue(entry.getValue());
        }

        double satisfactionRate = satisfiedDemand / totalDemand;

        // 计算各项成本
        double transportWh = 0.0; // 仓库间运输成本
        for (Map.Entry<Triple<String, String, String>, IloNumVar> entry : fVars.entrySet()) {
            Triple<String, String, String> key = entry.getKey();
            String from = key.first;
            String to = key.second;
            double distance = distances.getOrDefault(new Pair<>(from, to), 0.0);
            double flow = cplex.getValue(entry.getValue());
            transportWh += 0.9 / 10000.0 * distance * flow;
        }

        double transportCust = 0.0; // 仓库到门店运输成本
        for (Map.Entry<Triple<String, String, String>, IloNumVar> entry : uVars.entrySet()) {
            Triple<String, String, String> key = entry.getKey();
            String wh = key.first;
            String store = key.second;
            String sku = key.third;
            double distance = distances.getOrDefault(new Pair<>(wh, store), 0.0);
            double demandQty = demand.getOrDefault(new Triple<>(store, sku, ""), 0.0);
            double uValue = cplex.getValue(entry.getValue());
            transportCust += 1.45 / 10000.0 * distance * demandQty * uValue;
        }

        // 开仓成本
        double openingCost = 0.0;
        for (Map.Entry<String, IloNumVar> entry : yVars.entrySet()) {
            String wh = entry.getKey();
            double yValue = cplex.getValue(entry.getValue());
            openingCost += openingCosts.getOrDefault(wh, 0.0) * yValue;
        }

        // 智能系统成本
        double systemCost = 0.0;
        for (Map.Entry<String, IloNumVar> entry : zVars.entrySet()) {
            double zValue = cplex.getValue(entry.getValue());
            systemCost += 1.5 * zValue;
        }

        // 处理成本
        double processingCost = 0.0;
        for (String wh : processingCosts.keySet()) {
            if (cplex.getValue(yVars.get(wh)) > 0.5) {
                double procCost = processingCosts.get(wh);
                double totalQty = 0.0;

                if (cdcNames.contains(wh)) {
                    for (String rdc : rdcNames) {
                        for (String sku : Arrays.asList("im", "dm")) {
                            Triple<String, String, String> key = new Triple<>(wh, rdc, sku);
                            if (fVars.containsKey(key)) {
                                totalQty += 2.0 * cplex.getValue(fVars.get(key));
                            }
                        }
                    }

                    for (Order order : orders) {
                        Triple<String, String, String> key = new Triple<>(wh, order.storeName, order.sku);
                        if (uVars.containsKey(key)) {
                            totalQty += 2.0 * order.quantity * cplex.getValue(uVars.get(key));
                        }
                    }
                } else {
                    for (String sku : Arrays.asList("im", "dm")) {
                        String cdc = "im".equals(sku) ? portCDC : inlandCDC;
                        Triple<String, String, String> key = new Triple<>(cdc, wh, sku);
                        if (fVars.containsKey(key)) {
                            totalQty += cplex.getValue(fVars.get(key));
                        }
                    }

                    for (Order order : orders) {
                        Triple<String, String, String> key = new Triple<>(wh, order.storeName, order.sku);
                        if (uVars.containsKey(key)) {
                            totalQty += order.quantity * cplex.getValue(uVars.get(key));
                        }
                    }
                }

                double discountFactor = 1.0;
                if (zVars.containsKey(wh) && cplex.getValue(zVars.get(wh)) > 0.5) {
                    discountFactor = 0.6;
                }

                processingCost += procCost * totalQty * discountFactor;
            }
        }

        // 验证成本一致性
        double totalCostFromComponents = transportWh + transportCust + openingCost + processingCost + systemCost;
        System.out.printf("成本验证: 总成本分量=%.2f, 企业成本=%.2f, 补贴=%.2f, 社会总成本=%.2f%n",
                totalCostFromComponents, enterpriseCost, subsidy, socialCost);

        // 输出到CSV文件
        Path outputPath = Paths.get(outputDir, "问题二第二小问_补贴分析.csv");
        try (Writer writer = Files.newBufferedWriter(outputPath, StandardCharsets.UTF_8)) {
            // 写入表头
            writer.write("指标,值\n");
            writer.write(String.format("开仓数量,%d\n", openWarehouseCount));
            writer.write(String.format("时效满足率,%.4f\n", satisfactionRate));
            writer.write(String.format("补贴门槛,%.0f\n", SUBSIDY_THRESHOLD));
            writer.write(String.format("单位补贴,%.1f\n", SUBSIDY_PER_WAREHOUSE));
            writer.write(String.format("补贴金额,%.2f\n", subsidy));
            writer.write(String.format("企业成本,%.2f\n", enterpriseCost));
            writer.write(String.format("社会总成本,%.2f\n", socialCost));
            writer.write(String.format("仓库间运输成本,%.2f\n", transportWh));
            writer.write(String.format("仓库到门店运输成本,%.2f\n", transportCust));
            writer.write(String.format("开仓总成本,%.2f\n", openingCost));
            writer.write(String.format("出入仓处置总成本,%.2f\n", processingCost));
            writer.write(String.format("智能调度系统采购总成本,%.2f\n", systemCost));
        }

        System.out.println("问题二第二小问_补贴分析.csv已保存");
    }

    // 辅助类
    private static class Pair<A, B> {
        final A first;
        final B second;

        public Pair(A first, B second) {
            this.first = first;
            this.second = second;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof Pair)) return false;
            Pair<?, ?> pair = (Pair<?, ?>) o;
            return Objects.equals(first, pair.first) &&
                    Objects.equals(second, pair.second);
        }

        @Override
        public int hashCode() {
            return Objects.hash(first, second);
        }

        @Override
        public String toString() {
            return "(" + first + ", " + second + ")";
        }
    }

    private static class Triple<A, B, C> {
        final A first;
        final B second;
        final C third;

        public Triple(A first, B second, C third) {
            this.first = first;
            this.second = second;
            this.third = third;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof Triple)) return false;
            Triple<?, ?, ?> triple = (Triple<?, ?, ?>) o;
            return Objects.equals(first, triple.first) &&
                    Objects.equals(second, triple.second) &&
                    Objects.equals(third, triple.third);
        }

        @Override
        public int hashCode() {
            return Objects.hash(first, second, third);
        }

        @Override
        public String toString() {
            return "(" + first + ", " + second + ", " + third + ")";
        }
    }
}