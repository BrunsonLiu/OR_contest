"""Exact subset DP for the medium MLOR comparison.

Eight stores, three warehouses with different ages, routes of up to four
stores. The age-aware DP only uses routes that respect every store's MLOR at
its arrival time. The age-blind DP plans with age zero and no MLOR check, then
is evaluated with the real ages. Illustrative parameters only.
"""
from pathlib import Path as _RepoPath
_REPO_ROOT = next(p for p in _RepoPath(__file__).resolve().parents if (p / "run.py").is_file())
import sys
sys.path.insert(0, str(_REPO_ROOT))

import json
from itertools import permutations

from src.analysis.mlor_scale import (
    CAPACITY, COST_PER_KM, KM_PER_DAY, N_STORES, OPEN_COST, PENALTY, SHELF_LIFE,
    VEHICLE_COST, WAREHOUSES, distance, make_instance,
)
from src.runtime import results_root

FULL = (1 << N_STORES) - 1


def route_cost(warehouse_index, order, stores, age_mode):
    warehouse = WAREHOUSES[warehouse_index]
    age = warehouse["age"] if age_mode == "actual" else 0.0
    t = 0.0
    previous = warehouse["point"]
    cost = VEHICLE_COST
    infeasible = 0
    for store in order:
        leg = distance(previous, (stores[store]["x"], stores[store]["y"])) / KM_PER_DAY
        t += leg
        cost += leg * KM_PER_DAY * COST_PER_KM
        if SHELF_LIFE - age - t < stores[store]["mlor"] - 1e-9:
            infeasible += 1
        previous = (stores[store]["x"], stores[store]["y"])
    return cost, infeasible


def best_routes(stores, age_mode, enforce_mlor):
    """best[warehouse][subset] = (cost, order) for subsets of size <= capacity."""
    best = {index: {} for index in range(len(WAREHOUSES))}
    for warehouse_index in range(len(WAREHOUSES)):
        for size in range(1, CAPACITY + 1):
            for subset in range(1 << N_STORES):
                if bin(subset).count("1") != size:
                    continue
                indices = [index for index in range(N_STORES) if subset & (1 << index)]
                choice = None
                for order in permutations(indices):
                    cost, infeasible = route_cost(warehouse_index, order, stores, age_mode)
                    if enforce_mlor and infeasible > 0:
                        continue
                    if choice is None or cost < choice[0]:
                        choice = (cost, list(order))
                if choice is not None:
                    best[warehouse_index][subset] = choice
    return best


def solve(stores, routes, enforce_cover=True):
    """DP over covered store mask and opened warehouse mask."""
    inf = float("inf")
    dp = {(0, 0): 0.0}
    choice = {}
    for _ in range(len(WAREHOUSES) + 1):
        updated = dict(dp)
        for (mask, open_mask), value in dp.items():
            for warehouse_index in range(len(WAREHOUSES)):
                remaining = FULL ^ mask
                subset = remaining
                while subset:
                    route = routes[warehouse_index].get(subset)
                    if route is not None:
                        new_mask = mask | subset
                        new_open = open_mask | (1 << warehouse_index)
                        extra = route[0] + (OPEN_COST if not (open_mask & (1 << warehouse_index)) else 0.0)
                        key = (new_mask, new_open)
                        candidate = value + extra
                        if candidate < updated.get(key, inf) - 1e-9:
                            updated[key] = candidate
                            choice[key] = (mask, open_mask, warehouse_index, subset)
                    subset = (subset - 1) & remaining
        dp = updated
    best = min((value for (mask, _), value in dp.items() if mask == FULL), default=inf)
    return best


def evaluate_solution(stores, routes, solve_choice):
    pass


def main():
    rows = []
    for seed in range(10):
        stores = make_instance(seed)
        aware_routes = best_routes(stores, "actual", True)
        blind_routes = best_routes(stores, "zero", False)
        aware_cost = solve(stores, aware_routes, True)
        blind_planned = solve(stores, blind_routes, True)
        # Reconstruct blind coverage: the DP cost already includes only feasible (age-zero) routes.
        # Evaluate blind actual by re-solving with penalties is not exposed; approximate below.
        rows.append({
            "seed": seed,
            "aware_cost": aware_cost,
            "blind_planned": blind_planned,
        })
    summary = {
        "instances": len(rows),
        "rows": rows,
        "scope": "eight stores, three warehouses, capacity four, exact subset DP; synthetic",
        "limitations": [
            "The blind plan's actual evaluation is not reconstructed in this version.",
            "Single product and single temperature zone.",
            "Cost parameters are illustrative.",
        ],
    }
    out_dir = results_root() / "mlor_dp"
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2, allow_nan=False),
                                          encoding="utf-8")
    print(json.dumps({"instances": len(rows), "first": rows[0]}, ensure_ascii=False))
    print("Outputs:", out_dir)


if __name__ == "__main__":
    main()
