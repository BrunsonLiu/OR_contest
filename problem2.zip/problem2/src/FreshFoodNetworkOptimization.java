import ilog.concert.*;
import ilog.cplex.*;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.nio.charset.StandardCharsets;
import java.util.stream.Collectors;

public class FreshFoodNetworkOptimization {

    // 数据结构保持不变...
    private static class Warehouse {
        String name;
        String type;
        String location;

        public Warehouse(String name, String type, String location) {
            this.name = name;
            this.type = type;
            this.location = location;
        }
    }

    private static class Customer {
        String name;
        String type;
        String location;

        public Customer(String name, String type, String location) {
            this.name = name;
            this.type = type;
            this.location = location;
        }
    }

    private static class Order {
        String storeName;
        String sku;
        double quantity;

        public Order(String storeName, String sku, double quantity) {
            this.storeName = storeName;
            this.sku = sku;
            this.quantity = quantity;
        }
    }

    private static class MatrixEntry {
        String from;
        String to;
        double distance;
        double duration;

        public MatrixEntry(String from, String to, double distance, double duration) {
            this.from = from;
            this.to = to;
            this.distance = distance;
            this.duration = duration;
        }
    }

    private static class ProcessingInfo {
        double capacity;
        double openingFee;
        double processingFee;

        public ProcessingInfo(double capacity, double openingFee, double processingFee) {
            this.capacity = capacity;
            this.openingFee = openingFee;
            this.processingFee = processingFee;
        }
    }

    // 数据容器
    private List<Warehouse> warehouses = new ArrayList<>();
    private List<Customer> customers = new ArrayList<>();
    private List<Order> orders = new ArrayList<>();
    private List<MatrixEntry> matrixEntries = new ArrayList<>();
    private Map<String, ProcessingInfo> processingInfoMap = new HashMap<>();

    // 预处理后的数据
    private List<String> cdcNames = new ArrayList<>();
    private List<String> rdcNames = new ArrayList<>();
    private String portCDC;
    private String inlandCDC;
    private Map<String, String> storeCityMap = new HashMap<>();
    private Map<Triple<String, String, String>, Double> demand = new HashMap<>();
    private Map<Pair<String, String>, Double> distances = new HashMap<>();
    private Map<Pair<String, String>, Double> travelTimes = new HashMap<>();
    private Map<String, Double> capacities = new HashMap<>();
    private Map<String, Double> openingCosts = new HashMap<>();
    private Map<String, Double> processingCosts = new HashMap<>();

    private IloCplex cplex;

    // 决策变量映射
    private Map<String, IloNumVar> yVars = new HashMap<>();      // 仓库开设
    private Map<String, IloNumVar> zVars = new HashMap<>();      // 智能系统
    private Map<Triple<String, String, String>, IloNumVar> uVars = new HashMap<>(); // 服务关系
    private Map<Pair<String, String>, IloNumVar> vVars = new HashMap<>(); // 时效满足
    private Map<Triple<String, String, String>, IloNumVar> fVars = new HashMap<>(); // 调拨量
    private Map<String, IloNumVar> wVars = new HashMap<>();      // 辅助变量

    // 新增：分析参数
    private int currentTimeThreshold = 600;  // 默认600分钟
    private double currentSatisfactionRate = 0.95;  // 默认95%
    private String currentScenarioName = "default";

    // 用于存储分析结果的数据结构
    private static class SensitivityResult {
        int timeThreshold;
        double satisfactionRate;
        String scenarioName;
        double totalCost;
        double transportCostWh;
        double transportCostCust;
        double openingCost;
        double processingCost;
        double systemCost;
        int openWarehouseCount;
        double actualSatisfactionRate;
        double solveTime;
        IloCplex.Status solveStatus;

        // 用于生成表格行
        public List<String> toTableRow() {
            List<String> row = new ArrayList<>();
            row.add(String.format("T%d_S%.0f", timeThreshold, satisfactionRate * 100));
            row.add(String.valueOf(timeThreshold));
            row.add(String.format("%.0f%%", satisfactionRate * 100));
            row.add(String.valueOf(openWarehouseCount));
            row.add(String.format("%.4f", actualSatisfactionRate));
            row.add(String.format("%.2f", totalCost));
            row.add(String.format("%.2f", transportCostWh));
            row.add(String.format("%.2f", transportCostCust));
            row.add(String.format("%.2f", openingCost));
            row.add(String.format("%.2f", processingCost));
            row.add(String.format("%.2f", systemCost));
            row.add(String.format("%.2f", solveTime));
            row.add(solveStatus != null ? solveStatus.toString() : "Unknown");
            return row;
        }
    }

    private List<SensitivityResult> sensitivityResults = new ArrayList<>();

    public static void main(String[] args) {
        try {
            FreshFoodNetworkOptimization optimizer = new FreshFoodNetworkOptimization();

            // 加载数据
            optimizer.loadData();

            // 运行敏感性分析
            optimizer.runSensitivityAnalysis();

            // 输出综合性表格文件
            optimizer.outputComprehensiveTable();

            // 同时输出详细的敏感性分析结果
            optimizer.outputDetailedSensitivityAnalysis();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void runSensitivityAnalysis() throws Exception {
        // 定义要分析的参数组合
        int[] timeThresholds = {540, 570, 600, 630, 660};
        double[] satisfactionRates = {0.80, 0.85, 0.90, 0.95, 0.98};

        System.out.println("开始敏感性分析...");
        System.out.println("时间阈值: " + Arrays.toString(timeThresholds));
        System.out.println("满足率: " + Arrays.toString(satisfactionRates));
        System.out.println("总场景数: " + (timeThresholds.length * satisfactionRates.length));

        int scenarioCount = 0;
        int successfulScenarios = 0;

        // 遍历所有参数组合
        for (int timeThreshold : timeThresholds) {
            for (double satisfactionRate : satisfactionRates) {
                scenarioCount++;
                currentTimeThreshold = timeThreshold;
                currentSatisfactionRate = satisfactionRate;
                currentScenarioName = String.format("T%d_S%.0f", timeThreshold, satisfactionRate * 100);

                System.out.printf("\n[场景 %d/%d] %s (时间阈值=%d分钟, 满足率=%.1f%%)%n",
                        scenarioCount, timeThresholds.length * satisfactionRates.length,
                        currentScenarioName, timeThreshold, satisfactionRate * 100);

                try {
                    // 重新构建并求解模型
                    long startTime = System.currentTimeMillis();
                    buildModel();
                    solve();
                    SensitivityResult result = collectResults();
                    long endTime = System.currentTimeMillis();

                    result.timeThreshold = timeThreshold;
                    result.satisfactionRate = satisfactionRate;
                    result.scenarioName = currentScenarioName;
                    result.solveTime = (endTime - startTime) / 1000.0;  // 转换为秒

                    sensitivityResults.add(result);

                    if (result.solveStatus != null && result.solveStatus.equals(IloCplex.Status.Optimal)) {
                        successfulScenarios++;
                        System.out.printf("✓ 成功: 总成本=%.2f万元, 开仓数=%d, 实际满足率=%.2f%%%n",
                                result.totalCost, result.openWarehouseCount, result.actualSatisfactionRate * 100);
                    } else {
                        System.out.printf("✗ 失败: 求解状态=%s%n",
                                result.solveStatus != null ? result.solveStatus.toString() : "Unknown");
                    }

                    // 清理当前模型，为下一个场景做准备
                    if (cplex != null) {
                        cplex.end();
                        cplex = null;
                    }

                    // 重置变量映射
                    resetVariableMaps();

                } catch (Exception e) {
                    System.err.println("场景 " + currentScenarioName + " 求解失败: " + e.getMessage());

                    // 记录失败的结果
                    SensitivityResult failedResult = new SensitivityResult();
                    failedResult.timeThreshold = timeThreshold;
                    failedResult.satisfactionRate = satisfactionRate;
                    failedResult.scenarioName = currentScenarioName;
                    failedResult.solveStatus = IloCplex.Status.Unknown;
                    sensitivityResults.add(failedResult);
                }
            }
        }

        System.out.printf("\n敏感性分析完成！成功场景: %d/%d%n",
                successfulScenarios, scenarioCount);
    }

    private void resetVariableMaps() {
        yVars.clear();
        zVars.clear();
        uVars.clear();
        vVars.clear();
        fVars.clear();
        wVars.clear();
    }

    private void loadData() throws IOException {
        String inputDir = "C:/Users/86173/Desktop/ORcontest/2025年中国运筹学会运筹竞赛（数据驱动赛道）赛题/赛题3 生鲜商品仓网配送优化/input_data";

        // 读取仓库数据
        readWarehouses(Paths.get(inputDir, "df_wh.csv"));

        // 读取客户数据
        readCustomers(Paths.get(inputDir, "df_customer.csv"));

        // 读取订单数据
        readOrders(Paths.get(inputDir, "df_order.csv"));

        // 读取距离矩阵
        readMatrix(Paths.get(inputDir, "df_matrix.csv"));

        // 读取处理信息
        readProcessingInfo(Paths.get(inputDir, "df_proc.csv"));

        // 预处理数据
        preprocessData();
    }

    // CSV解析器保持不变...
    private List<Map<String, String>> parseCSV(Path filePath) throws IOException {
        List<Map<String, String>> data = new ArrayList<>();
        List<String> headers = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(filePath.toFile()))) {
            String line;
            int lineNum = 0;

            while ((line = br.readLine()) != null) {
                if (lineNum == 0) {
                    // 解析表头
                    headers = parseCSVLine(line);
                } else {
                    // 解析数据行
                    List<String> values = parseCSVLine(line);
                    if (values.size() == headers.size()) {
                        Map<String, String> row = new HashMap<>();
                        for (int i = 0; i < headers.size(); i++) {
                            row.put(headers.get(i), values.get(i));
                        }
                        data.add(row);
                    } else {
                        System.err.println("警告: 第 " + lineNum + " 行列数不匹配: " + values.size() + " != " + headers.size());
                    }
                }
                lineNum++;
            }
        }

        return data;
    }

    private List<String> parseCSVLine(String line) {
        List<String> result = new ArrayList<>();
        StringBuilder current = new StringBuilder();
        boolean inQuotes = false;

        for (int i = 0; i < line.length(); i++) {
            char c = line.charAt(i);

            if (c == '"') {
                if (inQuotes && i + 1 < line.length() && line.charAt(i + 1) == '"') {
                    // 转义的双引号
                    current.append('"');
                    i++;
                } else {
                    // 开始或结束引号
                    inQuotes = !inQuotes;
                }
            } else if (c == ',' && !inQuotes) {
                result.add(current.toString().trim());
                current = new StringBuilder();
            } else {
                current.append(c);
            }
        }

        // 添加最后一个字段
        result.add(current.toString().trim());

        // 处理字段中的引号
        for (int i = 0; i < result.size(); i++) {
            String field = result.get(i);
            if (field.startsWith("\"") && field.endsWith("\"") && field.length() > 1) {
                result.set(i, field.substring(1, field.length() - 1));
            }
        }

        return result;
    }

    private void readWarehouses(Path filePath) throws IOException {
        List<Map<String, String>> data = parseCSV(filePath);

        for (Map<String, String> record : data) {
            String name = record.get("Name");
            String type = record.get("Type");
            String location = record.get("Location");
            warehouses.add(new Warehouse(name, type, location));
        }
    }

    private void readCustomers(Path filePath) throws IOException {
        List<Map<String, String>> data = parseCSV(filePath);

        for (Map<String, String> record : data) {
            String name = record.get("Name");
            String type = record.get("Type");
            String location = record.get("Location");
            customers.add(new Customer(name, type, location));
            storeCityMap.put(name, location);
        }
    }

    private void readOrders(Path filePath) throws IOException {
        List<Map<String, String>> data = parseCSV(filePath);

        for (Map<String, String> record : data) {
            String name = record.get("Name");
            String sku = record.get("SKU");
            String qtyStr = record.get("qty");

            try {
                double qty = Double.parseDouble(qtyStr);
                orders.add(new Order(name, sku, qty));
                demand.put(new Triple<>(name, sku, ""), qty);
            } catch (NumberFormatException e) {
                System.err.println("无法解析订单数量: " + qtyStr + " for " + name + " SKU: " + sku);
            }
        }
    }

    private void readMatrix(Path filePath) throws IOException {
        List<Map<String, String>> data = parseCSV(filePath);

        for (Map<String, String> record : data) {
            String from = record.get("From");
            String to = record.get("To");
            String distanceStr = record.get("Distance");
            String durationStr = record.get("Duration");

            try {
                double distance = Double.parseDouble(distanceStr);
                double duration = Double.parseDouble(durationStr);
                matrixEntries.add(new MatrixEntry(from, to, distance, duration));

                distances.put(new Pair<>(from, to), distance);
                travelTimes.put(new Pair<>(from, to), duration);
            } catch (NumberFormatException e) {
                System.err.println("无法解析距离或时间: " + distanceStr + " / " + durationStr);
            }
        }
    }

    private void readProcessingInfo(Path filePath) throws IOException {
        List<Map<String, String>> data = parseCSV(filePath);

        for (Map<String, String> record : data) {
            String name = record.get("Name");
            String capacityStr = record.get("Capacity");
            String processingFeeStr = record.get("Processing_fee");
            String openingFeeStr = record.get("Opening_fee");

            try {
                double capacity = Double.parseDouble(capacityStr);
                double processingFee = Double.parseDouble(processingFeeStr);
                double openingFee = Double.parseDouble(openingFeeStr);
                processingInfoMap.put(name, new ProcessingInfo(capacity, openingFee, processingFee));
            } catch (NumberFormatException e) {
                System.err.println("无法解析仓储数据: " + name + " " + capacityStr + " " + processingFeeStr + " " + openingFeeStr);
            }
        }
    }

    private void preprocessData() {
        // 识别CDC和RDC
        for (Warehouse wh : warehouses) {
            if ("CDC".equals(wh.type)) {
                cdcNames.add(wh.name);
            } else if ("RDC".equals(wh.type)) {
                rdcNames.add(wh.name);
            }
        }

        // 识别港口CDC和内陆CDC
        for (String cdc : cdcNames) {
            if (cdc.contains("gang-kou")) {
                portCDC = cdc;
            } else if (cdc.contains("nei-lu")) {
                inlandCDC = cdc;
            }
        }

        System.out.println("港口CDC: " + portCDC);
        System.out.println("内陆CDC: " + inlandCDC);
        System.out.println("CDC数量: " + cdcNames.size());
        System.out.println("RDC数量: " + rdcNames.size());
        System.out.println("订单数量: " + orders.size());

        // 仓库参数
        for (Warehouse wh : warehouses) {
            if (("CDC".equals(wh.type) || "RDC".equals(wh.type))
                    && processingInfoMap.containsKey(wh.name)) {
                ProcessingInfo info = processingInfoMap.get(wh.name);
                capacities.put(wh.name, info.capacity);
                openingCosts.put(wh.name, info.openingFee);
                processingCosts.put(wh.name, info.processingFee);
            }
        }
    }

    private void buildModel() throws IloException {
        cplex = new IloCplex();
        cplex.setOut(null); // 减少输出

        // 设置求解参数
        cplex.setParam(IloCplex.Param.RootAlgorithm, IloCplex.Algorithm.Auto);
        cplex.setParam(IloCplex.Param.Threads, 8);
        cplex.setParam(IloCplex.Param.TimeLimit, 300); // 5分钟时间限制

        // 创建决策变量
        createVariables();

        // 添加约束
        addConstraints();

        // 添加目标函数
        addObjectiveFunction();
    }

    private void createVariables() throws IloException {
        // 1. 仓库开设变量 y
        for (Warehouse wh : warehouses) {
            if ("RDC".equals(wh.type) || "CDC".equals(wh.type)) {
                String varName = "y_" + wh.name;
                IloNumVar var;

                if (cdcNames.contains(wh.name)) {
                    // CDC必开
                    var = cplex.numVar(1.0, 1.0, IloNumVarType.Bool, varName);
                } else {
                    var = cplex.numVar(0.0, 1.0, IloNumVarType.Bool, varName);
                }

                yVars.put(wh.name, var);
            }
        }

        // 2. 智能系统变量 z
        for (Warehouse wh : warehouses) {
            if ("RDC".equals(wh.type) || "CDC".equals(wh.type)) {
                String varName = "z_" + wh.name;
                IloNumVar var = cplex.numVar(0.0, 1.0, IloNumVarType.Bool, varName);
                zVars.put(wh.name, var);
            }
        }

        // 3. 服务关系变量 u
        for (Order order : orders) {
            String store = order.storeName;
            String sku = order.sku;

            List<String> eligibleWarehouses = new ArrayList<>();
            if ("im".equals(sku)) {
                eligibleWarehouses.add(portCDC);
                eligibleWarehouses.addAll(rdcNames);
            } else {
                eligibleWarehouses.add(inlandCDC);
                eligibleWarehouses.addAll(rdcNames);
            }

            for (String wh : eligibleWarehouses) {
                String varName = String.format("u_%s_%s_%s", wh, store, sku);
                IloNumVar var = cplex.numVar(0.0, 1.0, IloNumVarType.Bool, varName);
                uVars.put(new Triple<>(wh, store, sku), var);
            }
        }

        // 4. 时效满足变量 v
        for (Order order : orders) {
            String store = order.storeName;
            String sku = order.sku;
            String varName = String.format("v_%s_%s", store, sku);
            IloNumVar var = cplex.numVar(0.0, 1.0, IloNumVarType.Bool, varName);
            vVars.put(new Pair<>(store, sku), var);
        }

        // 5. 调拨量变量 f
        for (String cdc : cdcNames) {
            for (String rdc : rdcNames) {
                for (String sku : Arrays.asList("im", "dm")) {
                    // 检查调拨是否允许
                    if (("im".equals(sku) && cdc.equals(portCDC))
                            || ("dm".equals(sku) && cdc.equals(inlandCDC))) {
                        String varName = String.format("f_%s_%s_%s", cdc, rdc, sku);
                        IloNumVar var = cplex.numVar(0.0, Double.MAX_VALUE, IloNumVarType.Float, varName);
                        fVars.put(new Triple<>(cdc, rdc, sku), var);
                    }
                }
            }
        }

        // 6. 线性化辅助变量 w
        for (Warehouse wh : warehouses) {
            if ("RDC".equals(wh.type) || "CDC".equals(wh.type)) {
                String varName = "w_" + wh.name;
                IloNumVar var = cplex.numVar(0.0, Double.MAX_VALUE, IloNumVarType.Float, varName);
                wVars.put(wh.name, var);
            }
        }
    }

    private void addConstraints() throws IloException {
        int constraintCount = 0;

        // 1. 单源服务约束
        for (Order order : orders) {
            String store = order.storeName;
            String sku = order.sku;

            List<String> eligibleWarehouses = new ArrayList<>();
            if ("im".equals(sku)) {
                eligibleWarehouses.add(portCDC);
                eligibleWarehouses.addAll(rdcNames);
            } else {
                eligibleWarehouses.add(inlandCDC);
                eligibleWarehouses.addAll(rdcNames);
            }

            IloLinearNumExpr expr = cplex.linearNumExpr();
            for (String wh : eligibleWarehouses) {
                Triple<String, String, String> key = new Triple<>(wh, store, sku);
                if (uVars.containsKey(key)) {
                    expr.addTerm(1.0, uVars.get(key));
                }
            }

            cplex.addEq(expr, 1.0, "single_source_" + constraintCount++);
        }

        // 2. 仓库开设与服务关系约束
        for (Map.Entry<Triple<String, String, String>, IloNumVar> entry : uVars.entrySet()) {
            Triple<String, String, String> key = entry.getKey();
            String wh = key.first;

            IloLinearNumExpr expr = cplex.linearNumExpr();
            expr.addTerm(1.0, entry.getValue());
            expr.addTerm(-1.0, yVars.get(wh));

            cplex.addLe(expr, 0.0, "service_open_" + constraintCount++);
        }

        // 3. RDC流量平衡约束
        for (String rdc : rdcNames) {
            for (String sku : Arrays.asList("im", "dm")) {
                IloLinearNumExpr expr = cplex.linearNumExpr();

                // RDC出发的配送
                for (Order order : orders) {
                    if (order.sku.equals(sku)) {
                        Triple<String, String, String> key = new Triple<>(rdc, order.storeName, sku);
                        if (uVars.containsKey(key)) {
                            expr.addTerm(order.quantity, uVars.get(key));
                        }
                    }
                }

                // CDC到RDC的调拨
                String cdc = "im".equals(sku) ? portCDC : inlandCDC;
                Triple<String, String, String> fKey = new Triple<>(cdc, rdc, sku);
                if (fVars.containsKey(fKey)) {
                    expr.addTerm(-1.0, fVars.get(fKey));
                }

                cplex.addEq(expr, 0.0, "balance_" + constraintCount++);
            }
        }

        // 4. 容量约束
        for (String wh : capacities.keySet()) {
            IloLinearNumExpr expr = cplex.linearNumExpr();

            if (cdcNames.contains(wh)) {
                // CDC的出库包括调拨和直接配送
                for (String rdc : rdcNames) {
                    for (String sku : Arrays.asList("im", "dm")) {
                        Triple<String, String, String> key = new Triple<>(wh, rdc, sku);
                        if (fVars.containsKey(key)) {
                            expr.addTerm(1.0, fVars.get(key));
                        }
                    }
                }

                for (Order order : orders) {
                    Triple<String, String, String> key = new Triple<>(wh, order.storeName, order.sku);
                    if (uVars.containsKey(key)) {
                        expr.addTerm(order.quantity, uVars.get(key));
                    }
                }
            } else {
                // RDC只有直接配送
                for (Order order : orders) {
                    Triple<String, String, String> key = new Triple<>(wh, order.storeName, order.sku);
                    if (uVars.containsKey(key)) {
                        expr.addTerm(order.quantity, uVars.get(key));
                    }
                }
            }

            // 减去容量*y
            if (yVars.containsKey(wh)) {
                expr.addTerm(-capacities.get(wh), yVars.get(wh));
                cplex.addLe(expr, 0.0, "capacity_" + constraintCount++);
            }
        }

        // 5. 线性化约束：w_j = z_j * 总流量
        double bigM = 1000000.0;

        for (String wh : wVars.keySet()) {
            if (!processingCosts.containsKey(wh)) continue;

            // 计算总流量
            IloLinearNumExpr totalFlowExpr = cplex.linearNumExpr();

            if (cdcNames.contains(wh)) {
                // CDC的总流量（出库量）
                for (String rdc : rdcNames) {
                    for (String sku : Arrays.asList("im", "dm")) {
                        Triple<String, String, String> key = new Triple<>(wh, rdc, sku);
                        if (fVars.containsKey(key)) {
                            totalFlowExpr.addTerm(1.0, fVars.get(key));
                        }
                    }
                }

                for (Order order : orders) {
                    Triple<String, String, String> key = new Triple<>(wh, order.storeName, order.sku);
                    if (uVars.containsKey(key)) {
                        totalFlowExpr.addTerm(order.quantity, uVars.get(key));
                    }
                }
            } else {
                // RDC的总流量（流入量）
                for (String sku : Arrays.asList("im", "dm")) {
                    String cdc = "im".equals(sku) ? portCDC : inlandCDC;
                    Triple<String, String, String> key = new Triple<>(cdc, wh, sku);
                    if (fVars.containsKey(key)) {
                        totalFlowExpr.addTerm(1.0, fVars.get(key));
                    }
                }

                for (Order order : orders) {
                    Triple<String, String, String> key = new Triple<>(wh, order.storeName, order.sku);
                    if (uVars.containsKey(key)) {
                        totalFlowExpr.addTerm(order.quantity, uVars.get(key));
                    }
                }
            }

            // 线性化约束
            IloLinearNumExpr expr1 = cplex.linearNumExpr();
            expr1.addTerm(1.0, wVars.get(wh));
            expr1.addTerm(-bigM, zVars.get(wh));
            cplex.addLe(expr1, 0.0, "linear1_" + constraintCount++);

            IloLinearNumExpr expr2 = cplex.linearNumExpr();
            expr2.addTerm(1.0, wVars.get(wh));
            cplex.addLe(expr2, totalFlowExpr, "linear2_" + constraintCount++);

            IloLinearNumExpr expr3 = cplex.linearNumExpr();
            expr3.addTerm(1.0, wVars.get(wh));
            expr3.addTerm(bigM, zVars.get(wh));
            cplex.addGe(expr3, totalFlowExpr, "linear3_" + constraintCount++);
        }

        // 6. 时效约束 - 使用当前参数
        for (Map.Entry<Pair<String, String>, IloNumVar> entry : vVars.entrySet()) {
            Pair<String, String> key = entry.getKey();
            String store = key.first;
            String sku = key.second;

            List<String> eligibleWarehouses = new ArrayList<>();
            if ("im".equals(sku)) {
                eligibleWarehouses.add(portCDC);
                eligibleWarehouses.addAll(rdcNames);
            } else {
                eligibleWarehouses.add(inlandCDC);
                eligibleWarehouses.addAll(rdcNames);
            }

            for (String wh : eligibleWarehouses) {
                Triple<String, String, String> uKey = new Triple<>(wh, store, sku);
                if (uVars.containsKey(uKey)) {
                    double travelTime = travelTimes.getOrDefault(new Pair<>(wh, store), Double.MAX_VALUE);

                    if (travelTime <= currentTimeThreshold) {
                        // v >= u
                        IloLinearNumExpr expr = cplex.linearNumExpr();
                        expr.addTerm(-1.0, entry.getValue());
                        expr.addTerm(1.0, uVars.get(uKey));
                        cplex.addLe(expr, 0.0, "time1_" + constraintCount++);
                    } else {
                        // v <= 1 - u
                        IloLinearNumExpr expr = cplex.linearNumExpr();
                        expr.addTerm(1.0, entry.getValue());
                        expr.addTerm(1.0, uVars.get(uKey));
                        cplex.addLe(expr, 1.0, "time2_" + constraintCount++);
                    }
                }
            }
        }

        // 整体时效约束 - 使用当前参数
        double totalDemand = orders.stream().mapToDouble(o -> o.quantity).sum();
        IloLinearNumExpr expr = cplex.linearNumExpr();
        for (Map.Entry<Pair<String, String>, IloNumVar> entry : vVars.entrySet()) {
            Pair<String, String> key = entry.getKey();
            double demandQty = demand.getOrDefault(new Triple<>(key.first, key.second, ""), 0.0);
            expr.addTerm(demandQty, entry.getValue());
        }
        cplex.addGe(expr, currentSatisfactionRate * totalDemand,
                "overall_time_window_" + constraintCount++);

        // 7. 智能系统采购约束
        for (String wh : zVars.keySet()) {
            if (yVars.containsKey(wh)) {
                IloLinearNumExpr expr7 = cplex.linearNumExpr();
                expr7.addTerm(1.0, zVars.get(wh));
                expr7.addTerm(-1.0, yVars.get(wh));
                cplex.addLe(expr7, 0.0, "system_" + constraintCount++);
            }
        }

        // 8. v变量与仓库选择的逻辑一致性约束
        for (Map.Entry<Pair<String, String>, IloNumVar> entry : vVars.entrySet()) {
            Pair<String, String> key = entry.getKey();
            String store = key.first;
            String sku = key.second;

            List<String> eligibleWarehouses = new ArrayList<>();
            if ("im".equals(sku)) {
                eligibleWarehouses.add(portCDC);
                eligibleWarehouses.addAll(rdcNames);
            } else {
                eligibleWarehouses.add(inlandCDC);
                eligibleWarehouses.addAll(rdcNames);
            }

            // 确保如果v=1，至少有一个时效满足的仓库被选中
            IloLinearNumExpr expr1 = cplex.linearNumExpr();
            expr1.addTerm(1.0, entry.getValue());

            for (String wh : eligibleWarehouses) {
                Triple<String, String, String> uKey = new Triple<>(wh, store, sku);
                if (uVars.containsKey(uKey)) {
                    double travelTime = travelTimes.getOrDefault(new Pair<>(wh, store), Double.MAX_VALUE);
                    if (travelTime <= currentTimeThreshold) {
                        expr1.addTerm(-1.0, uVars.get(uKey));
                    }
                }
            }
            cplex.addLe(expr1, 0.0, "v_implies_timely_warehouse_" + constraintCount++);
        }
    }

    private void addObjectiveFunction() throws IloException {
        IloLinearNumExpr objective = cplex.linearNumExpr();

        // 1. 开仓成本
        for (Map.Entry<String, IloNumVar> entry : yVars.entrySet()) {
            String wh = entry.getKey();
            double cost = openingCosts.getOrDefault(wh, 0.0);
            objective.addTerm(cost, entry.getValue());
        }

        // 2. 智能系统成本
        for (Map.Entry<String, IloNumVar> entry : zVars.entrySet()) {
            objective.addTerm(1.5, entry.getValue());
        }

        // 3. 运输成本 - 仓库到门店
        for (Map.Entry<Triple<String, String, String>, IloNumVar> entry : uVars.entrySet()) {
            Triple<String, String, String> key = entry.getKey();
            String wh = key.first;
            String store = key.second;
            String sku = key.third;

            double distance = distances.getOrDefault(new Pair<>(wh, store), 0.0);
            double demandQty = demand.getOrDefault(new Triple<>(store, sku, ""), 0.0);
            double cost = 1.45 / 10000.0 * distance * demandQty;

            objective.addTerm(cost, entry.getValue());
        }

        // 4. 运输成本 - CDC到RDC
        for (Map.Entry<Triple<String, String, String>, IloNumVar> entry : fVars.entrySet()) {
            Triple<String, String, String> key = entry.getKey();
            String cdc = key.first;
            String rdc = key.second;

            double distance = distances.getOrDefault(new Pair<>(cdc, rdc), 0.0);
            double cost = 0.9 / 10000.0 * distance;

            objective.addTerm(cost, entry.getValue());
        }

        // 5. 处理成本
        for (String wh : processingCosts.keySet()) {
            double procCost = processingCosts.get(wh);

            if (cdcNames.contains(wh)) {
                for (String rdc : rdcNames) {
                    for (String sku : Arrays.asList("im", "dm")) {
                        Triple<String, String, String> key = new Triple<>(wh, rdc, sku);
                        if (fVars.containsKey(key)) {
                            objective.addTerm(2.0 * procCost, fVars.get(key));
                        }
                    }
                }

                for (Order order : orders) {
                    Triple<String, String, String> key = new Triple<>(wh, order.storeName, order.sku);
                    if (uVars.containsKey(key)) {
                        objective.addTerm(2.0 * procCost * order.quantity, uVars.get(key));
                    }
                }
            } else {
                for (String sku : Arrays.asList("im", "dm")) {
                    String cdc = "im".equals(sku) ? portCDC : inlandCDC;
                    Triple<String, String, String> key = new Triple<>(cdc, wh, sku);
                    if (fVars.containsKey(key)) {
                        objective.addTerm(procCost, fVars.get(key));
                    }
                }

                for (Order order : orders) {
                    Triple<String, String, String> key = new Triple<>(wh, order.storeName, order.sku);
                    if (uVars.containsKey(key)) {
                        objective.addTerm(procCost * order.quantity, uVars.get(key));
                    }
                }
            }

            // 折扣部分
            if (wVars.containsKey(wh)) {
                if (cdcNames.contains(wh)) {
                    objective.addTerm(-0.8 * procCost, wVars.get(wh));
                } else {
                    objective.addTerm(-0.4 * procCost, wVars.get(wh));
                }
            }
        }

        cplex.addMinimize(objective);
    }

    private void solve() throws IloException {
        if (cplex.solve()) {
            // 静默求解，不在控制台输出
        }
    }

    private SensitivityResult collectResults() throws IloException {
        SensitivityResult result = new SensitivityResult();
        result.solveStatus = cplex.getStatus();

        if (cplex.getStatus() == null || !cplex.getStatus().equals(IloCplex.Status.Optimal)) {
            return result;
        }

        result.totalCost = cplex.getObjValue();

        // 计算开仓数量
        int openWarehouseCount = 0;
        for (String wh : yVars.keySet()) {
            if (cplex.getValue(yVars.get(wh)) > 0.5) {
                openWarehouseCount++;
            }
        }
        result.openWarehouseCount = openWarehouseCount;

        // 计算满意需求率
        double satisfiedDemand = 0.0;
        double totalDemand = orders.stream().mapToDouble(o -> o.quantity).sum();
        for (Map.Entry<Pair<String, String>, IloNumVar> entry : vVars.entrySet()) {
            Pair<String, String> key = entry.getKey();
            double demandQty = demand.getOrDefault(new Triple<>(key.first, key.second, ""), 0.0);
            satisfiedDemand += demandQty * cplex.getValue(entry.getValue());
        }
        result.actualSatisfactionRate = satisfiedDemand / totalDemand;

        // 计算各项成本
        result.transportCostWh = 0.0; // 仓库间运输成本
        for (Map.Entry<Triple<String, String, String>, IloNumVar> entry : fVars.entrySet()) {
            Triple<String, String, String> key = entry.getKey();
            String from = key.first;
            String to = key.second;
            double distance = distances.getOrDefault(new Pair<>(from, to), 0.0);
            double flow = cplex.getValue(entry.getValue());
            result.transportCostWh += 0.9 / 10000.0 * distance * flow;
        }

        result.transportCostCust = 0.0; // 仓库到门店运输成本
        for (Map.Entry<Triple<String, String, String>, IloNumVar> entry : uVars.entrySet()) {
            Triple<String, String, String> key = entry.getKey();
            String wh = key.first;
            String store = key.second;
            String sku = key.third;
            double distance = distances.getOrDefault(new Pair<>(wh, store), 0.0);
            double demandQty = demand.getOrDefault(new Triple<>(store, sku, ""), 0.0);
            double uValue = cplex.getValue(entry.getValue());
            result.transportCostCust += 1.45 / 10000.0 * distance * demandQty * uValue;
        }

        // 开仓成本
        result.openingCost = 0.0;
        for (Map.Entry<String, IloNumVar> entry : yVars.entrySet()) {
            String wh = entry.getKey();
            double yValue = cplex.getValue(entry.getValue());
            result.openingCost += openingCosts.getOrDefault(wh, 0.0) * yValue;
        }

        // 智能系统成本
        result.systemCost = 0.0;
        for (Map.Entry<String, IloNumVar> entry : zVars.entrySet()) {
            double zValue = cplex.getValue(entry.getValue());
            result.systemCost += 1.5 * zValue;
        }

        // 处理成本
        result.processingCost = 0.0;
        for (String wh : processingCosts.keySet()) {
            if (cplex.getValue(yVars.get(wh)) > 0.5) {
                double procCost = processingCosts.get(wh);
                double totalQty = 0.0;

                if (cdcNames.contains(wh)) {
                    for (String rdc : rdcNames) {
                        for (String sku : Arrays.asList("im", "dm")) {
                            Triple<String, String, String> key = new Triple<>(wh, rdc, sku);
                            if (fVars.containsKey(key)) {
                                totalQty += 2.0 * cplex.getValue(fVars.get(key));
                            }
                        }
                    }

                    for (Order order : orders) {
                        Triple<String, String, String> key = new Triple<>(wh, order.storeName, order.sku);
                        if (uVars.containsKey(key)) {
                            totalQty += 2.0 * order.quantity * cplex.getValue(uVars.get(key));
                        }
                    }
                } else {
                    for (String sku : Arrays.asList("im", "dm")) {
                        String cdc = "im".equals(sku) ? portCDC : inlandCDC;
                        Triple<String, String, String> key = new Triple<>(cdc, wh, sku);
                        if (fVars.containsKey(key)) {
                            totalQty += cplex.getValue(fVars.get(key));
                        }
                    }

                    for (Order order : orders) {
                        Triple<String, String, String> key = new Triple<>(wh, order.storeName, order.sku);
                        if (uVars.containsKey(key)) {
                            totalQty += order.quantity * cplex.getValue(uVars.get(key));
                        }
                    }
                }

                double discountFactor = 1.0;
                if (zVars.containsKey(wh) && cplex.getValue(zVars.get(wh)) > 0.5) {
                    discountFactor = 0.6;
                }

                result.processingCost += procCost * totalQty * discountFactor;
            }
        }

        return result;
    }

    private void outputComprehensiveTable() throws IOException {
        String outputDir = "./2025年中国运筹学会运筹竞赛（数据驱动赛道）赛题/赛题3 生鲜商品仓网配送优化/output_result";
        Files.createDirectories(Paths.get(outputDir));

        // 过滤出成功求解的场景
        List<SensitivityResult> successfulResults = sensitivityResults.stream()
                .filter(r -> r.solveStatus != null && r.solveStatus.equals(IloCplex.Status.Optimal))
                .collect(Collectors.toList());

        // 按时间阈值排序，然后按满足率排序
        successfulResults.sort(Comparator
                .comparingInt((SensitivityResult r) -> r.timeThreshold)
                .thenComparingDouble(r -> r.satisfactionRate));

        // 创建综合性表格文件
        Path tablePath = Paths.get(outputDir, "仓网业务表现综合表格.csv");

        try (Writer writer = Files.newBufferedWriter(tablePath, StandardCharsets.UTF_8)) {
            // 写入表头
            List<String> headers = Arrays.asList(
                    "场景编号",
                    "时效满足要求（分钟）",
                    "时效满足率要求",
                    "开仓数量",
                    "实际时效满足率",
                    "总物流成本（单位：万元）",
                    "仓库之间的运输总成本（单位：万元）",
                    "仓库到门店的运输总成本（单位：万元）",
                    "开仓总成本（单位：万元）",
                    "出入仓处置总成本（单位：万元）",
                    "智能调度系统采购总成本（单位：万元）",
                    "求解时间（秒）",
                    "求解状态"
            );

            writer.write(String.join(",", headers));
            writer.write("\n");

            // 写入数据行
            for (SensitivityResult result : successfulResults) {
                List<String> row = result.toTableRow();
                writer.write(String.join(",", row));
                writer.write("\n");
            }

            // 写入汇总信息
            writer.write("\n");
            writer.write("汇总统计,,,平均值,,,,,,,,,\n");

            // 计算各项平均值
            if (!successfulResults.isEmpty()) {
                double avgOpenWarehouse = successfulResults.stream()
                        .mapToInt(r -> r.openWarehouseCount).average().orElse(0);
                double avgSatisfactionRate = successfulResults.stream()
                        .mapToDouble(r -> r.actualSatisfactionRate).average().orElse(0);
                double avgTotalCost = successfulResults.stream()
                        .mapToDouble(r -> r.totalCost).average().orElse(0);
                double avgTransportWh = successfulResults.stream()
                        .mapToDouble(r -> r.transportCostWh).average().orElse(0);
                double avgTransportCust = successfulResults.stream()
                        .mapToDouble(r -> r.transportCostCust).average().orElse(0);
                double avgOpeningCost = successfulResults.stream()
                        .mapToDouble(r -> r.openingCost).average().orElse(0);
                double avgProcessingCost = successfulResults.stream()
                        .mapToDouble(r -> r.processingCost).average().orElse(0);
                double avgSystemCost = successfulResults.stream()
                        .mapToDouble(r -> r.systemCost).average().orElse(0);
                double avgSolveTime = successfulResults.stream()
                        .mapToDouble(r -> r.solveTime).average().orElse(0);

                List<String> avgRow = Arrays.asList(
                        "",
                        "",
                        "",
                        String.format("%.1f", avgOpenWarehouse),
                        String.format("%.4f", avgSatisfactionRate),
                        String.format("%.2f", avgTotalCost),
                        String.format("%.2f", avgTransportWh),
                        String.format("%.2f", avgTransportCust),
                        String.format("%.2f", avgOpeningCost),
                        String.format("%.2f", avgProcessingCost),
                        String.format("%.2f", avgSystemCost),
                        String.format("%.2f", avgSolveTime),
                        ""
                );

                writer.write(String.join(",", avgRow));
                writer.write("\n");

                // 计算最小值
                writer.write(",,,最小值,,,,,,,,,\n");
                int minOpenWarehouse = successfulResults.stream()
                        .mapToInt(r -> r.openWarehouseCount).min().orElse(0);
                double minSatisfactionRate = successfulResults.stream()
                        .mapToDouble(r -> r.actualSatisfactionRate).min().orElse(0);
                double minTotalCost = successfulResults.stream()
                        .mapToDouble(r -> r.totalCost).min().orElse(0);
                double minTransportWh = successfulResults.stream()
                        .mapToDouble(r -> r.transportCostWh).min().orElse(0);
                double minTransportCust = successfulResults.stream()
                        .mapToDouble(r -> r.transportCostCust).min().orElse(0);
                double minOpeningCost = successfulResults.stream()
                        .mapToDouble(r -> r.openingCost).min().orElse(0);
                double minProcessingCost = successfulResults.stream()
                        .mapToDouble(r -> r.processingCost).min().orElse(0);
                double minSystemCost = successfulResults.stream()
                        .mapToDouble(r -> r.systemCost).min().orElse(0);
                double minSolveTime = successfulResults.stream()
                        .mapToDouble(r -> r.solveTime).min().orElse(0);

                List<String> minRow = Arrays.asList(
                        "",
                        "",
                        "",
                        String.valueOf(minOpenWarehouse),
                        String.format("%.4f", minSatisfactionRate),
                        String.format("%.2f", minTotalCost),
                        String.format("%.2f", minTransportWh),
                        String.format("%.2f", minTransportCust),
                        String.format("%.2f", minOpeningCost),
                        String.format("%.2f", minProcessingCost),
                        String.format("%.2f", minSystemCost),
                        String.format("%.2f", minSolveTime),
                        ""
                );

                writer.write(String.join(",", minRow));
                writer.write("\n");

                // 计算最大值
                writer.write(",,,最大值,,,,,,,,,\n");
                int maxOpenWarehouse = successfulResults.stream()
                        .mapToInt(r -> r.openWarehouseCount).max().orElse(0);
                double maxSatisfactionRate = successfulResults.stream()
                        .mapToDouble(r -> r.actualSatisfactionRate).max().orElse(0);
                double maxTotalCost = successfulResults.stream()
                        .mapToDouble(r -> r.totalCost).max().orElse(0);
                double maxTransportWh = successfulResults.stream()
                        .mapToDouble(r -> r.transportCostWh).max().orElse(0);
                double maxTransportCust = successfulResults.stream()
                        .mapToDouble(r -> r.transportCostCust).max().orElse(0);
                double maxOpeningCost = successfulResults.stream()
                        .mapToDouble(r -> r.openingCost).max().orElse(0);
                double maxProcessingCost = successfulResults.stream()
                        .mapToDouble(r -> r.processingCost).max().orElse(0);
                double maxSystemCost = successfulResults.stream()
                        .mapToDouble(r -> r.systemCost).max().orElse(0);
                double maxSolveTime = successfulResults.stream()
                        .mapToDouble(r -> r.solveTime).max().orElse(0);

                List<String> maxRow = Arrays.asList(
                        "",
                        "",
                        "",
                        String.valueOf(maxOpenWarehouse),
                        String.format("%.4f", maxSatisfactionRate),
                        String.format("%.2f", maxTotalCost),
                        String.format("%.2f", maxTransportWh),
                        String.format("%.2f", maxTransportCust),
                        String.format("%.2f", maxOpeningCost),
                        String.format("%.2f", maxProcessingCost),
                        String.format("%.2f", maxSystemCost),
                        String.format("%.2f", maxSolveTime),
                        ""
                );

                writer.write(String.join(",", maxRow));
                writer.write("\n");
            }

            // 写入分析结论
            writer.write("\n");
            writer.write("分析结论:\n");
            writer.write("1. 时效满足要求越严格（时间阈值越小），总物流成本越高\n");
            writer.write("2. 时效满足率要求越高，总物流成本越高\n");
            writer.write("3. 运输成本通常占总成本的较大比例\n");
            writer.write("4. 开仓成本相对固定，不随时效要求变化\n");
            writer.write("5. 智能系统可以显著降低处理成本\n");
        }

        System.out.println("\n=========================================");
        System.out.println("综合性表格文件已生成: " + tablePath);
        System.out.println("成功场景数: " + successfulResults.size());
        System.out.println("=========================================");

        // 输出关键洞察
        if (!successfulResults.isEmpty()) {
            outputKeyInsights(successfulResults);
        }
    }

    private void outputDetailedSensitivityAnalysis() throws IOException {
        String outputDir = "./2025年中国运筹学会运筹竞赛（数据驱动赛道）赛题/赛题3 生鲜商品仓网配送优化/output_result";
        Files.createDirectories(Paths.get(outputDir));

        // 创建详细敏感性分析文件
        Path detailedPath = Paths.get(outputDir, "敏感性分析详细结果.csv");

        try (Writer writer = Files.newBufferedWriter(detailedPath, StandardCharsets.UTF_8)) {
            // 写入表头
            List<String> headers = Arrays.asList(
                    "场景编号",
                    "时间阈值(分钟)",
                    "满足率要求(%)",
                    "开仓数量",
                    "实际满足率(%)",
                    "总物流成本(万元)",
                    "仓库间运输成本(万元)",
                    "仓库到门店运输成本(万元)",
                    "开仓成本(万元)",
                    "处理成本(万元)",
                    "智能系统成本(万元)",
                    "求解时间(秒)",
                    "求解状态"
            );

            writer.write(String.join(",", headers));
            writer.write("\n");

            // 按场景编号排序
            sensitivityResults.sort(Comparator
                    .comparingInt((SensitivityResult r) -> r.timeThreshold)
                    .thenComparingDouble(r -> r.satisfactionRate));

            // 写入所有场景结果
            for (SensitivityResult result : sensitivityResults) {
                List<String> row = Arrays.asList(
                        result.scenarioName,
                        String.valueOf(result.timeThreshold),
                        String.format("%.0f", result.satisfactionRate * 100),
                        result.solveStatus != null && result.solveStatus.equals(IloCplex.Status.Optimal) ?
                                String.valueOf(result.openWarehouseCount) : "N/A",
                        result.solveStatus != null && result.solveStatus.equals(IloCplex.Status.Optimal) ?
                                String.format("%.2f", result.actualSatisfactionRate * 100) : "N/A",
                        result.solveStatus != null && result.solveStatus.equals(IloCplex.Status.Optimal) ?
                                String.format("%.2f", result.totalCost) : "N/A",
                        result.solveStatus != null && result.solveStatus.equals(IloCplex.Status.Optimal) ?
                                String.format("%.2f", result.transportCostWh) : "N/A",
                        result.solveStatus != null && result.solveStatus.equals(IloCplex.Status.Optimal) ?
                                String.format("%.2f", result.transportCostCust) : "N/A",
                        result.solveStatus != null && result.solveStatus.equals(IloCplex.Status.Optimal) ?
                                String.format("%.2f", result.openingCost) : "N/A",
                        result.solveStatus != null && result.solveStatus.equals(IloCplex.Status.Optimal) ?
                                String.format("%.2f", result.processingCost) : "N/A",
                        result.solveStatus != null && result.solveStatus.equals(IloCplex.Status.Optimal) ?
                                String.format("%.2f", result.systemCost) : "N/A",
                        String.format("%.2f", result.solveTime),
                        result.solveStatus != null ? result.solveStatus.toString() : "Unknown"
                );

                writer.write(String.join(",", row));
                writer.write("\n");
            }
        }

        System.out.println("详细敏感性分析文件已生成: " + detailedPath);
    }

    private void outputKeyInsights(List<SensitivityResult> successfulResults) {
        System.out.println("\n关键洞察:");
        System.out.println("=========================================");

        // 找出成本最低和最高的场景
        SensitivityResult minCostResult = successfulResults.stream()
                .min(Comparator.comparingDouble(r -> r.totalCost))
                .orElse(null);

        SensitivityResult maxCostResult = successfulResults.stream()
                .max(Comparator.comparingDouble(r -> r.totalCost))
                .orElse(null);

        if (minCostResult != null && maxCostResult != null) {
            double costDifference = maxCostResult.totalCost - minCostResult.totalCost;
            double relativeDifference = (costDifference / minCostResult.totalCost) * 100;

            System.out.printf("1. 成本分析:\n");
            System.out.printf("   - 成本范围: %.2f万元 ~ %.2f万元\n", minCostResult.totalCost, maxCostResult.totalCost);
            System.out.printf("   - 绝对差异: %.2f万元\n", costDifference);
            System.out.printf("   - 相对差异: %.1f%%\n", relativeDifference);
            System.out.printf("   - 最低成本场景: %s (时间=%d分钟, 要求=%.0f%%)\n",
                    minCostResult.scenarioName, minCostResult.timeThreshold, minCostResult.satisfactionRate * 100);
            System.out.printf("   - 最高成本场景: %s (时间=%d分钟, 要求=%.0f%%)\n",
                    maxCostResult.scenarioName, maxCostResult.timeThreshold, maxCostResult.satisfactionRate * 100);
        }

        // 分析不同时间阈值的影响
        System.out.println("\n2. 时间阈值影响:");
        Map<Integer, List<SensitivityResult>> byTime = successfulResults.stream()
                .collect(Collectors.groupingBy(r -> r.timeThreshold));

        for (int time : new int[]{540, 570, 600, 630, 660}) {
            if (byTime.containsKey(time)) {
                List<SensitivityResult> results = byTime.get(time);
                double avgCost = results.stream().mapToDouble(r -> r.totalCost).average().orElse(0);
                double minCost = results.stream().mapToDouble(r -> r.totalCost).min().orElse(0);
                double maxCost = results.stream().mapToDouble(r -> r.totalCost).max().orElse(0);

                System.out.printf("   - %d分钟: 平均成本=%.2f万元 (范围: %.2f~%.2f万元)\n",
                        time, avgCost, minCost, maxCost);
            }
        }

        // 分析不同满足率的影响
        System.out.println("\n3. 满足率影响:");
        Map<Double, List<SensitivityResult>> byRate = successfulResults.stream()
                .collect(Collectors.groupingBy(r -> r.satisfactionRate));

        for (double rate : new double[]{0.80, 0.85, 0.90, 0.95, 0.98}) {
            if (byRate.containsKey(rate)) {
                List<SensitivityResult> results = byRate.get(rate);
                double avgCost = results.stream().mapToDouble(r -> r.totalCost).average().orElse(0);
                double minCost = results.stream().mapToDouble(r -> r.totalCost).min().orElse(0);
                double maxCost = results.stream().mapToDouble(r -> r.totalCost).max().orElse(0);

                System.out.printf("   - %.0f%%: 平均成本=%.2f万元 (范围: %.2f~%.2f万元)\n",
                        rate * 100, avgCost, minCost, maxCost);
            }
        }

        // 成本构成分析
        System.out.println("\n4. 成本构成分析（以中等要求场景T600_S95为例）:");
        SensitivityResult middleScenario = successfulResults.stream()
                .filter(r -> r.timeThreshold == 600 && r.satisfactionRate == 0.95)
                .findFirst()
                .orElse(successfulResults.get(successfulResults.size() / 2));

        if (middleScenario != null) {
            double total = middleScenario.totalCost;
            System.out.printf("   - 总成本: %.2f万元\n", total);
            System.out.printf("   - 运输成本占比: %.1f%%\n",
                    ((middleScenario.transportCostWh + middleScenario.transportCostCust) / total) * 100);
            System.out.printf("   - 开仓成本占比: %.1f%%\n",
                    (middleScenario.openingCost / total) * 100);
            System.out.printf("   - 处理成本占比: %.1f%%\n",
                    (middleScenario.processingCost / total) * 100);
            System.out.printf("   - 智能系统成本占比: %.1f%%\n",
                    (middleScenario.systemCost / total) * 100);
        }
    }

    // 辅助类保持不变...
    private static class Pair<A, B> {
        final A first;
        final B second;

        public Pair(A first, B second) {
            this.first = first;
            this.second = second;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof Pair)) return false;
            Pair<?, ?> pair = (Pair<?, ?>) o;
            return Objects.equals(first, pair.first) &&
                    Objects.equals(second, pair.second);
        }

        @Override
        public int hashCode() {
            return Objects.hash(first, second);
        }

        @Override
        public String toString() {
            return "(" + first + ", " + second + ")";
        }
    }

    private static class Triple<A, B, C> {
        final A first;
        final B second;
        final C third;

        public Triple(A first, B second, C third) {
            this.first = first;
            this.second = second;
            this.third = third;
        }

        @Override
        public boolean equals(Object o) {
            if (this == o) return true;
            if (!(o instanceof Triple)) return false;
            Triple<?, ?, ?> triple = (Triple<?, ?, ?>) o;
            return Objects.equals(first, triple.first) &&
                    Objects.equals(second, triple.second) &&
                    Objects.equals(third, triple.third);
        }

        @Override
        public int hashCode() {
            return Objects.hash(first, second, third);
        }

        @Override
        public String toString() {
            return "(" + first + ", " + second + ", " + third + ")";
        }
    }
}

